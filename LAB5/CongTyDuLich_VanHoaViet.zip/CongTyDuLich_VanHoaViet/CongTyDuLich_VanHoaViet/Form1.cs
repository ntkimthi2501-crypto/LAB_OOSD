﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace CongTyDuLich_VanHoaViet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.Text = "Kiểm tra kết nối SQL Server";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(500, 250);

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "KIỂM TRA KẾT NỐI DATABASE";
            lblTieuDe.Font = new Font("Arial", 14, FontStyle.Bold);
            lblTieuDe.AutoSize = true;
            lblTieuDe.Location = new Point(75, 35);
            this.Controls.Add(lblTieuDe);

            Label lblKetQua = new Label();
            lblKetQua.AutoSize = false;
            lblKetQua.Size = new Size(420, 35);
            lblKetQua.Location = new Point(35, 90);
            lblKetQua.TextAlign = ContentAlignment.MiddleCenter;
            lblKetQua.Font = new Font("Arial", 11, FontStyle.Bold);
            this.Controls.Add(lblKetQua);

            Button btnKiemTra = new Button();
            btnKiemTra.Text = "Kiểm tra kết nối";
            btnKiemTra.Size = new Size(150, 40);
            btnKiemTra.Location = new Point(165, 145);
            this.Controls.Add(btnKiemTra);

            btnKiemTra.Click += (sender, e) =>
            {
                KiemTraKetNoi kiemTra = new KiemTraKetNoi();

                if (kiemTra.KiemTra())
                {
                    lblKetQua.Text = "Kết nối database thành công!";
                    lblKetQua.ForeColor = Color.Green;
                }
                else
                {
                    lblKetQua.Text = "Kết nối thất bại! Kiểm tra lại SQL Server.";
                    lblKetQua.ForeColor = Color.Red;
                }
            };
        }
    }
}