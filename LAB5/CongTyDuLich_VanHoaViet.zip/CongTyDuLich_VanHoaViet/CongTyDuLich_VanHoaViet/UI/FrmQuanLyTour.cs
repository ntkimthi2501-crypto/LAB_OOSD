﻿
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CongTyDuLich_VanHoaViet.UI
{
    public partial class FrmQuanLyTour : Form
    {
        private DataGridView dgvTour;
        private Button btnLamMoi;
        private Label lblTieuDe;

        public FrmQuanLyTour()
        {
            InitializeComponent();
            TaoGiaoDien();
            HienThiDanhSachTour();
        }

        private void TaoGiaoDien()
        {
            this.Text = "QUẢN LÝ TOUR DU LỊCH";
            this.Size = new Size(900, 550);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.WhiteSmoke;

            // Tiêu đề
            lblTieuDe = new Label();
            lblTieuDe.Text = "DANH SÁCH TOUR DU LỊCH";
            lblTieuDe.Font = new Font("Arial", 18, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.DarkBlue;
            lblTieuDe.AutoSize = true;
            lblTieuDe.Location = new Point(25, 20);
            this.Controls.Add(lblTieuDe);

            // Nút làm mới
            btnLamMoi = new Button();
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.Font = new Font("Arial", 10, FontStyle.Bold);
            btnLamMoi.Size = new Size(110, 35);
            btnLamMoi.Location = new Point(750, 60);
            btnLamMoi.BackColor = Color.FromArgb(41, 85, 135);
            btnLamMoi.ForeColor = Color.White;
            btnLamMoi.FlatStyle = FlatStyle.Flat;
            btnLamMoi.Click += BtnLamMoi_Click;
            this.Controls.Add(btnLamMoi);

            // Bảng danh sách tour
            dgvTour = new DataGridView();
            dgvTour.Location = new Point(25, 110);
            dgvTour.Size = new Size(830, 350);
            dgvTour.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            dgvTour.ReadOnly = true;
            dgvTour.AllowUserToAddRows = false;
            dgvTour.AllowUserToDeleteRows = false;
            dgvTour.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvTour.MultiSelect = false;
            dgvTour.BackgroundColor = Color.White;
            dgvTour.RowHeadersVisible = false;
            dgvTour.AutoGenerateColumns = true;

            this.Controls.Add(dgvTour);
        }

        // Hiển thị danh sách tour
        private void HienThiDanhSachTour()
        {
            try
            {
                TourService service = new TourService();

                dgvTour.DataSource = service.LayDanhSachTour();

                if (dgvTour.Columns.Contains("maTour"))
                    dgvTour.Columns["maTour"].HeaderText = "Mã tour";

                if (dgvTour.Columns.Contains("tenTour"))
                    dgvTour.Columns["tenTour"].HeaderText = "Tên tour";

                if (dgvTour.Columns.Contains("soNgay"))
                    dgvTour.Columns["soNgay"].HeaderText = "Số ngày";

                if (dgvTour.Columns.Contains("soDem"))
                    dgvTour.Columns["soDem"].HeaderText = "Số đêm";

                if (dgvTour.Columns.Contains("donGia"))
                {
                    dgvTour.Columns["donGia"].HeaderText = "Đơn giá";
                    dgvTour.Columns["donGia"].DefaultCellStyle.Format = "N0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không tải được danh sách tour!\n\nChi tiết: "
                    + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // Xử lý nút làm mới
        private void BtnLamMoi_Click(object sender, EventArgs e)
        {
            HienThiDanhSachTour();
        }
    }
}

