﻿
using System.Data;

namespace CongTyDuLich_VanHoaViet
{
    public class TourService
    {
        private TourData tourData = new TourData();

        public DataTable LayDanhSachTour()
        {
            return tourData.LayDanhSachTour();
        }
    }
}