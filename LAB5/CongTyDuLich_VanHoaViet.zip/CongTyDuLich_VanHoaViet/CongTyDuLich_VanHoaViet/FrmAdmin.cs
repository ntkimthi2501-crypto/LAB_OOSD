﻿
using System;
using System.Drawing;
using System.Windows.Forms;
using CongTyDuLich_VanHoaViet.UI;
namespace CongTyDuLich_VanHoaViet
{
    public partial class FrmAdmin : Form
    {
        public FrmAdmin()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            this.Text = "ADMIN - CÔNG TY DU LỊCH VĂN HÓA VIỆT";
            this.Size = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.WhiteSmoke;

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "HỆ THỐNG QUẢN LÝ DU LỊCH VĂN HÓA VIỆT";
            lblTieuDe.Font = new Font("Arial", 20, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.DarkBlue;
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            lblTieuDe.Dock = DockStyle.Top;
            lblTieuDe.Height = 80;
            this.Controls.Add(lblTieuDe);

            Panel pnlMenu = new Panel();
            pnlMenu.Location = new Point(30, 100);
            pnlMenu.Size = new Size(1020, 520);
            pnlMenu.AutoScroll = true;
            this.Controls.Add(pnlMenu);

            string[] chucNang =
            {
                "Quản lý Tour",
                "Quản lý Điểm dừng",
                "Quản lý Phương tiện",
                "Quản lý Điểm tham quan",
                "Quản lý Khách hàng",
                "Quản lý Đăng ký đoàn",
                "Quản lý Thành viên đoàn",
                "Quản lý Chuyến đi",
                "Quản lý Đăng ký chuyến",
                "Quản lý Điểm bán vé",
                "Quản lý Điểm đón",
                "Quản lý Nhân viên hướng dẫn",
                "Quản lý Phân công",
                "Quản lý Phiếu khảo sát"
            };

            int rongNut = 300;
            int caoNut = 65;
            int khoangCach = 25;
            int soCot = 3;

            for (int i = 0; i < chucNang.Length; i++)
            {
                Button btn = new Button();

                btn.Text = chucNang[i];
                btn.Font = new Font("Arial", 11, FontStyle.Bold);
                btn.ForeColor = Color.White;
                btn.BackColor = Color.FromArgb(41, 85, 135);
                btn.FlatStyle = FlatStyle.Flat;
                btn.Size = new Size(rongNut, caoNut);

                int cot = i % soCot;
                int hang = i / soCot;

                btn.Location = new Point(
                    20 + cot * (rongNut + khoangCach),
                    20 + hang * (caoNut + khoangCach)
                );

                // Gắn sự kiện khi bấm nút
                btn.Click += BtnChucNang_Click;

                pnlMenu.Controls.Add(btn);
            }
        }

        private void BtnChucNang_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            if (btn == null)
                return;

            if (btn.Text == "Quản lý Tour")
            {
                FrmQuanLyTour frm = new FrmQuanLyTour();
                frm.ShowDialog();
            }
            else
            {
                MessageBox.Show(
                    "Chức năng này sẽ được xây dựng sau.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }
    }
}