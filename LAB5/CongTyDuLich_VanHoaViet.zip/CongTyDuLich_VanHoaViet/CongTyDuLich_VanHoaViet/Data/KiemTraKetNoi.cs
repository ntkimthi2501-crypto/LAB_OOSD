﻿
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CongTyDuLich_VanHoaViet
{
    public class KiemTraKetNoi
    {
        public bool KiemTra()
        {
            KetNoi kn = new KetNoi();

            try
            {
                using (SqlConnection conn = kn.TaoKetNoi())
                {
                    conn.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}