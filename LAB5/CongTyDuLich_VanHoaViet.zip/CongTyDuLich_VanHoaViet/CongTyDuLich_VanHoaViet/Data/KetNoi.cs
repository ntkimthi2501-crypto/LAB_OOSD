﻿
using System.Data.SqlClient;

namespace CongTyDuLich_VanHoaViet
{
    public class KetNoi
    {
        private readonly string chuoiKetNoi =
            @"Data Source=DESKTOP-CQGMJPS;Initial Catalog=QuanLyTourVanHoaViet;Integrated Security=True;TrustServerCertificate=True";

        public SqlConnection TaoKetNoi()
        {
            return new SqlConnection(chuoiKetNoi);
        }
    }
}