﻿
using System.Data;
using System.Data.SqlClient;

namespace CongTyDuLich_VanHoaViet
{
    public class TourData
    {
        public DataTable LayDanhSachTour()
        {
            DataTable bang = new DataTable();
            KetNoi kn = new KetNoi();

            using (SqlConnection conn = kn.TaoKetNoi())
            {
                string sql = @"
                    SELECT maTour, tenTour, soNgay, soDem, donGia
                    FROM Tour
                    ORDER BY maTour";

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(sql, conn))
                {
                    adapter.Fill(bang);
                }
            }

            return bang;
        }
    }
}