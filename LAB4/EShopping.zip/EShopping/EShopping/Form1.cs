﻿
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EShopping
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            KiemTraKetNoi();
        }

        private void KiemTraKetNoi()
        {
            try
            {
                using (SqlConnection conn = Database.GetConnection())
                {
                    conn.Open();

                    MessageBox.Show(
                        "Kết nối cơ sở dữ liệu EShoppingDB thành công!",
                        "Thông báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }

                this.Hide();

                using (FrmMain main = new FrmMain())
                {
                    main.ShowDialog();
                }

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Kết nối cơ sở dữ liệu thất bại!\n\n" + ex.Message,
                    "Lỗi kết nối",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}