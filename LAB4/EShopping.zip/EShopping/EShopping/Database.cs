﻿
using System.Data.SqlClient;

namespace EShopping
{
    public class Database
    {
        private static string connectionString =
            @"Server=.;Database=EShoppingDB;Trusted_Connection=True;TrustServerCertificate=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}