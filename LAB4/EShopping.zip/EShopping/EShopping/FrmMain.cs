﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace EShopping
{
    public class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeMain();
        }

        private void InitializeMain()
        {
            this.Text = "Hệ thống quản lý e-SHOPPING";
            this.Size = new Size(900, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "HỆ THỐNG QUẢN LÝ E-SHOPPING";
            lblTieuDe.Font = new Font("Arial", 20, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.Black;
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            lblTieuDe.SetBounds(100, 30, 700, 50);
            this.Controls.Add(lblTieuDe);

            TaoNut("Quản lý nhóm sản phẩm", 180, 120);
            TaoNut("Quản lý sản phẩm", 480, 120);

            TaoNut("Quản lý khách hàng", 180, 210);
            TaoNut("Quản lý giỏ hàng", 480, 210);

            TaoNut("Quản lý đơn hàng", 180, 300);
            TaoNut("Quản lý thanh toán", 480, 300);

            TaoNut("Quản lý loại giao hàng", 180, 390);
            TaoNut("Thoát chương trình", 480, 390);
        }

        private void TaoNut(string noiDung, int x, int y)
        {
            Button btn = new Button();

            btn.Text = noiDung;
            btn.Font = new Font("Arial", 11, FontStyle.Regular);
            btn.Size = new Size(240, 55);
            btn.Location = new Point(x, y);
            btn.BackColor = Color.LightSteelBlue;
            btn.ForeColor = Color.Black;
            btn.Cursor = Cursors.Hand;

            btn.Click += (sender, e) =>
            {
                if (noiDung == "Thoát chương trình")
                {
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show(
                        "Bạn đã chọn: " + noiDung,
                        "Thông báo"
                    );
                }
            };

            this.Controls.Add(btn);
        }
    }
}