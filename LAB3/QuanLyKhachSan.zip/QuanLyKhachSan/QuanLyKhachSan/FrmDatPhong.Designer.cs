﻿using System;

namespace QuanLyKhachSan
{
    partial class FrmDatPhong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabDatPhong = new System.Windows.Forms.TabControl();
            this.tabKhachHang = new System.Windows.Forms.TabPage();
            this.tabDatPhongPage = new System.Windows.Forms.TabPage();
            this.tabNhanPhong = new System.Windows.Forms.TabPage();

            this.lblTieuDe = new System.Windows.Forms.Label();

            this.lblSoPhieu = new System.Windows.Forms.Label();
            this.txtSoPhieu = new System.Windows.Forms.TextBox();

            this.lblMaKhach = new System.Windows.Forms.Label();
            this.txtMaKhach = new System.Windows.Forms.TextBox();

            this.lblKhach = new System.Windows.Forms.Label();
            this.txtKhach = new System.Windows.Forms.TextBox();

            this.lblKenhDat = new System.Windows.Forms.Label();
            this.cboKenhDat = new System.Windows.Forms.ComboBox();

            this.lblTienCoc = new System.Windows.Forms.Label();
            this.txtTienCoc = new System.Windows.Forms.TextBox();

            this.lblNgayNhan = new System.Windows.Forms.Label();
            this.dtNgayNhan = new System.Windows.Forms.DateTimePicker();

            this.lblNgayTra = new System.Windows.Forms.Label();
            this.dtNgayTra = new System.Windows.Forms.DateTimePicker();

            this.dgvPhong = new System.Windows.Forms.DataGridView();

            this.lblPhongChon = new System.Windows.Forms.Label();
            this.txtPhongChon = new System.Windows.Forms.TextBox();

            this.lblSoNguoi = new System.Windows.Forms.Label();
            this.txtSoNguoi = new System.Windows.Forms.TextBox();

            this.lblDonGia = new System.Windows.Forms.Label();
            this.txtDonGia = new System.Windows.Forms.TextBox();

            this.btnLapPhieuDat = new System.Windows.Forms.Button();

            this.lblDanhSachPhieu = new System.Windows.Forms.Label();
            this.dgvPhieuDat = new System.Windows.Forms.DataGridView();

            this.tabDatPhong.SuspendLayout();
            this.tabDatPhongPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuDat)).BeginInit();
            this.SuspendLayout();

            // tabDatPhong
            this.tabDatPhong.Controls.Add(this.tabKhachHang);
            this.tabDatPhong.Controls.Add(this.tabDatPhongPage);
            this.tabDatPhong.Controls.Add(this.tabNhanPhong);
            this.tabDatPhong.Location = new System.Drawing.Point(10, 10);
            this.tabDatPhong.Name = "tabDatPhong";
            this.tabDatPhong.SelectedIndex = 1;
            this.tabDatPhong.Size = new System.Drawing.Size(980, 570);
            this.tabDatPhong.TabIndex = 0;

            // tabKhachHang
            this.tabKhachHang.Location = new System.Drawing.Point(4, 29);
            this.tabKhachHang.Name = "tabKhachHang";
            this.tabKhachHang.Size = new System.Drawing.Size(972, 537);
            this.tabKhachHang.TabIndex = 0;
            this.tabKhachHang.Text = "Khách hàng";
            this.tabKhachHang.UseVisualStyleBackColor = true;

            // tabDatPhongPage
            this.tabDatPhongPage.Controls.Add(this.lblTieuDe);
            this.tabDatPhongPage.Controls.Add(this.lblSoPhieu);
            this.tabDatPhongPage.Controls.Add(this.txtSoPhieu);
            this.tabDatPhongPage.Controls.Add(this.lblMaKhach);
            this.tabDatPhongPage.Controls.Add(this.txtMaKhach);
            this.tabDatPhongPage.Controls.Add(this.lblKhach);
            this.tabDatPhongPage.Controls.Add(this.txtKhach);
            this.tabDatPhongPage.Controls.Add(this.lblKenhDat);
            this.tabDatPhongPage.Controls.Add(this.cboKenhDat);
            this.tabDatPhongPage.Controls.Add(this.lblTienCoc);
            this.tabDatPhongPage.Controls.Add(this.txtTienCoc);
            this.tabDatPhongPage.Controls.Add(this.lblNgayNhan);
            this.tabDatPhongPage.Controls.Add(this.dtNgayNhan);
            this.tabDatPhongPage.Controls.Add(this.lblNgayTra);
            this.tabDatPhongPage.Controls.Add(this.dtNgayTra);
            this.tabDatPhongPage.Controls.Add(this.dgvPhong);
            this.tabDatPhongPage.Controls.Add(this.lblPhongChon);
            this.tabDatPhongPage.Controls.Add(this.txtPhongChon);
            this.tabDatPhongPage.Controls.Add(this.lblSoNguoi);
            this.tabDatPhongPage.Controls.Add(this.txtSoNguoi);
            this.tabDatPhongPage.Controls.Add(this.lblDonGia);
            this.tabDatPhongPage.Controls.Add(this.txtDonGia);
            this.tabDatPhongPage.Controls.Add(this.btnLapPhieuDat);
            this.tabDatPhongPage.Controls.Add(this.lblDanhSachPhieu);
            this.tabDatPhongPage.Controls.Add(this.dgvPhieuDat);
            this.tabDatPhongPage.Location = new System.Drawing.Point(4, 29);
            this.tabDatPhongPage.Name = "tabDatPhongPage";
            this.tabDatPhongPage.Size = new System.Drawing.Size(972, 537);
            this.tabDatPhongPage.TabIndex = 1;
            this.tabDatPhongPage.Text = "Đặt phòng";
            this.tabDatPhongPage.UseVisualStyleBackColor = true;

            // tabNhanPhong
            this.tabNhanPhong.Location = new System.Drawing.Point(4, 29);
            this.tabNhanPhong.Name = "tabNhanPhong";
            this.tabNhanPhong.Size = new System.Drawing.Size(972, 537);
            this.tabNhanPhong.TabIndex = 2;
            this.tabNhanPhong.Text = "Nhận phòng / Người lưu trú";
            this.tabNhanPhong.UseVisualStyleBackColor = true;

            // lblTieuDe
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font(
                "Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.Location = new System.Drawing.Point(25, 15);
            this.lblTieuDe.Text = "Đặt phòng";

            // lblSoPhieu
            this.lblSoPhieu.AutoSize = true;
            this.lblSoPhieu.Location = new System.Drawing.Point(25, 65);
            this.lblSoPhieu.Text = "Số phiếu đặt:";

            this.txtSoPhieu.Location = new System.Drawing.Point(130, 61);
            this.txtSoPhieu.Name = "txtSoPhieu";
            this.txtSoPhieu.Size = new System.Drawing.Size(120, 27);
            this.txtSoPhieu.Text = "DP001";

            // lblMaKhach
            this.lblMaKhach.AutoSize = true;
            this.lblMaKhach.Location = new System.Drawing.Point(270, 65);
            this.lblMaKhach.Text = "Mã khách:";

            this.txtMaKhach.Location = new System.Drawing.Point(350, 61);
            this.txtMaKhach.Name = "txtMaKhach";
            this.txtMaKhach.Size = new System.Drawing.Size(110, 27);
            this.txtMaKhach.Text = "KH01";

            // lblKhach
            this.lblKhach.AutoSize = true;
            this.lblKhach.Location = new System.Drawing.Point(480, 65);
            this.lblKhach.Text = "Khách:";

            this.txtKhach.Location = new System.Drawing.Point(535, 61);
            this.txtKhach.Name = "txtKhach";
            this.txtKhach.Size = new System.Drawing.Size(150, 27);
            this.txtKhach.Text = "Nguyễn Văn A";

            // lblKenhDat
            this.lblKenhDat.AutoSize = true;
            this.lblKenhDat.Location = new System.Drawing.Point(25, 105);
            this.lblKenhDat.Text = "Kênh đặt:";

            this.cboKenhDat.Location = new System.Drawing.Point(130, 101);
            this.cboKenhDat.Name = "cboKenhDat";
            this.cboKenhDat.Size = new System.Drawing.Size(150, 28);
            this.cboKenhDat.DropDownStyle =
                System.Windows.Forms.ComboBoxStyle.DropDownList;

            // lblTienCoc
            this.lblTienCoc.AutoSize = true;
            this.lblTienCoc.Location = new System.Drawing.Point(310, 105);
            this.lblTienCoc.Text = "Tiền cọc:";

            this.txtTienCoc.Location = new System.Drawing.Point(380, 101);
            this.txtTienCoc.Name = "txtTienCoc";
            this.txtTienCoc.Size = new System.Drawing.Size(120, 27);
            this.txtTienCoc.Text = "500000";

            // lblNgayNhan
            this.lblNgayNhan.AutoSize = true;
            this.lblNgayNhan.Location = new System.Drawing.Point(520, 105);
            this.lblNgayNhan.Text = "Ngày nhận:";

            this.dtNgayNhan.Location = new System.Drawing.Point(600, 101);
            this.dtNgayNhan.Name = "dtNgayNhan";
            this.dtNgayNhan.Size = new System.Drawing.Size(150, 27);
            this.dtNgayNhan.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgayNhan.Value = DateTime.Today.AddDays(1);

            // lblNgayTra
            this.lblNgayTra.AutoSize = true;
            this.lblNgayTra.Location = new System.Drawing.Point(765, 105);
            this.lblNgayTra.Text = "Ngày trả:";

            this.dtNgayTra.Location = new System.Drawing.Point(825, 101);
            this.dtNgayTra.Name = "dtNgayTra";
            this.dtNgayTra.Size = new System.Drawing.Size(130, 27);
            this.dtNgayTra.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgayTra.Value = DateTime.Today.AddDays(2);

            // dgvPhong
            this.dgvPhong.Location = new System.Drawing.Point(25, 150);
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.Size = new System.Drawing.Size(600, 180);
            this.dgvPhong.AllowUserToAddRows = false;
            this.dgvPhong.RowHeadersVisible = false;

            // lblPhongChon
            this.lblPhongChon.AutoSize = true;
            this.lblPhongChon.Location = new System.Drawing.Point(650, 155);
            this.lblPhongChon.Text = "Phòng chọn:";

            this.txtPhongChon.Location = new System.Drawing.Point(740, 151);
            this.txtPhongChon.Name = "txtPhongChon";
            this.txtPhongChon.Size = new System.Drawing.Size(150, 27);

            // lblSoNguoi
            this.lblSoNguoi.AutoSize = true;
            this.lblSoNguoi.Location = new System.Drawing.Point(650, 200);
            this.lblSoNguoi.Text = "Số người:";

            this.txtSoNguoi.Location = new System.Drawing.Point(740, 196);
            this.txtSoNguoi.Name = "txtSoNguoi";
            this.txtSoNguoi.Size = new System.Drawing.Size(150, 27);
            this.txtSoNguoi.Text = "1";

            // lblDonGia
            this.lblDonGia.AutoSize = true;
            this.lblDonGia.Location = new System.Drawing.Point(650, 245);
            this.lblDonGia.Text = "Đơn giá/ngày:";

            this.txtDonGia.Location = new System.Drawing.Point(740, 241);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(150, 27);

            // btnLapPhieuDat
            this.btnLapPhieuDat.Location = new System.Drawing.Point(740, 285);
            this.btnLapPhieuDat.Name = "btnLapPhieuDat";
            this.btnLapPhieuDat.Size = new System.Drawing.Size(150, 40);
            this.btnLapPhieuDat.Text = "Lập phiếu đặt";
            this.btnLapPhieuDat.UseVisualStyleBackColor = true;

            // lblDanhSachPhieu
            this.lblDanhSachPhieu.AutoSize = true;
            this.lblDanhSachPhieu.Location = new System.Drawing.Point(25, 345);
            this.lblDanhSachPhieu.Text = "Phiếu đặt phòng:";

            // dgvPhieuDat
            this.dgvPhieuDat.Location = new System.Drawing.Point(25, 375);
            this.dgvPhieuDat.Name = "dgvPhieuDat";
            this.dgvPhieuDat.Size = new System.Drawing.Size(920, 140);
            this.dgvPhieuDat.AllowUserToAddRows = false;
            this.dgvPhieuDat.RowHeadersVisible = false;

            // FrmDatPhong
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.tabDatPhong);
            this.Name = "FrmDatPhong";
            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Khách hàng - Đặt phòng - Nhận phòng";

            this.tabDatPhong.ResumeLayout(false);
            this.tabDatPhongPage.ResumeLayout(false);
            this.tabDatPhongPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuDat)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabDatPhong;
        private System.Windows.Forms.TabPage tabKhachHang;
        private System.Windows.Forms.TabPage tabDatPhongPage;
        private System.Windows.Forms.TabPage tabNhanPhong;

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblSoPhieu;
        private System.Windows.Forms.TextBox txtSoPhieu;

        private System.Windows.Forms.Label lblMaKhach;
        private System.Windows.Forms.TextBox txtMaKhach;

        private System.Windows.Forms.Label lblKhach;
        private System.Windows.Forms.TextBox txtKhach;

        private System.Windows.Forms.Label lblKenhDat;
        private System.Windows.Forms.ComboBox cboKenhDat;

        private System.Windows.Forms.Label lblTienCoc;
        private System.Windows.Forms.TextBox txtTienCoc;

        private System.Windows.Forms.Label lblNgayNhan;
        private System.Windows.Forms.DateTimePicker dtNgayNhan;

        private System.Windows.Forms.Label lblNgayTra;
        private System.Windows.Forms.DateTimePicker dtNgayTra;

        private System.Windows.Forms.DataGridView dgvPhong;

        private System.Windows.Forms.Label lblPhongChon;
        private System.Windows.Forms.TextBox txtPhongChon;

        private System.Windows.Forms.Label lblSoNguoi;
        private System.Windows.Forms.TextBox txtSoNguoi;

        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.TextBox txtDonGia;

        private System.Windows.Forms.Button btnLapPhieuDat;

        private System.Windows.Forms.Label lblDanhSachPhieu;
        private System.Windows.Forms.DataGridView dgvPhieuDat;
    }
}