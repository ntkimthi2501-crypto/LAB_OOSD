﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmThongKe : Form
    {
        public FrmThongKe()
        {
            InitializeComponent();

            LoadThongKe();
        }

        private void LoadThongKe()
        {
            try
            {
                using (SqlConnection cn = Db.GetConnection())
                {
                    cn.Open();

                    // ==============================
                    // TỔNG SỐ PHÒNG
                    // ==============================
                    lblTongPhongValue.Text =
                        LaySoLuong(
                            cn,
                            "SELECT COUNT(*) FROM Phong")
                        .ToString();

                    // ==============================
                    // PHÒNG TRỐNG
                    // ==============================
                    lblPhongTrongValue.Text =
                        LaySoLuong(
                            cn,
                            "SELECT COUNT(*) FROM Phong WHERE TrangThai = N'Trống'")
                        .ToString();

                    // ==============================
                    // PHÒNG ĐÃ ĐẶT
                    // ==============================
                    lblPhongDaDatValue.Text =
                        LaySoLuong(
                            cn,
                            "SELECT COUNT(*) FROM Phong WHERE TrangThai = N'Đã đặt'")
                        .ToString();

                    // ==============================
                    // PHÒNG ĐANG Ở
                    // ==============================
                    lblPhongDangOValue.Text =
                        LaySoLuong(
                            cn,
                            "SELECT COUNT(*) FROM Phong WHERE TrangThai = N'Đang ở'")
                        .ToString();

                    // ==============================
                    // TỔNG KHÁCH HÀNG
                    // ==============================
                    lblTongKhachValue.Text =
                        LaySoLuong(
                            cn,
                            "SELECT COUNT(*) FROM KhachHang")
                        .ToString();

                    // ==============================
                    // TỔNG PHIẾU ĐẶT
                    // ==============================
                    lblTongPhieuDatValue.Text =
                        LaySoLuong(
                            cn,
                            "SELECT COUNT(*) FROM PhieuDatPhong")
                        .ToString();

                    // ==============================
                    // TỔNG TIỀN DỊCH VỤ
                    // ==============================
                    decimal tongDichVu =
                        LayTien(
                            cn,
                            @"SELECT ISNULL(
                                SUM(ThanhTien), 0
                              )
                              FROM ChiTietPhieuSuDungDV");

                    lblTongDichVuValue.Text =
                        tongDichVu.ToString("N0") + " đ";

                    // ==============================
                    // TỔNG TIỀN ĐỀN BÙ
                    // ==============================
                    decimal tongDenBu =
                        LayTien(
                            cn,
                            @"SELECT ISNULL(
                                SUM(SoTien), 0
                              )
                              FROM ChiTietPhieuDenBu");

                    lblTongDenBuValue.Text =
                        tongDenBu.ToString("N0") + " đ";

                    // ==============================
                    // LOAD DANH SÁCH PHÒNG
                    // ==============================
                    LoadDanhSachPhong(cn);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải dữ liệu thống kê:\n\n"
                    + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private int LaySoLuong(
            SqlConnection cn,
            string sql)
        {
            using (SqlCommand cmd =
                new SqlCommand(sql, cn))
            {
                return Convert.ToInt32(
                    cmd.ExecuteScalar());
            }
        }

        private decimal LayTien(
            SqlConnection cn,
            string sql)
        {
            using (SqlCommand cmd =
                new SqlCommand(sql, cn))
            {
                return Convert.ToDecimal(
                    cmd.ExecuteScalar());
            }
        }

        private void LoadDanhSachPhong(
            SqlConnection cn)
        {
            string sql = @"
                SELECT
                    p.SoPhong,
                    k.TenKhuVuc,
                    p.SoNguoiToiDa,
                    p.DonGiaNgay,
                    p.TrangThai
                FROM Phong p
                INNER JOIN KhuVuc k
                    ON p.MaKhuVuc = k.MaKhuVuc
                ORDER BY p.SoPhong";

            using (SqlDataAdapter da =
                new SqlDataAdapter(sql, cn))
            {
                DataTable dt = new DataTable();

                da.Fill(dt);

                dgvThongKe.DataSource = dt;
            }

            DinhDangGrid();
        }

        private void DinhDangGrid()
        {
            if (dgvThongKe.Columns.Count == 0)
                return;

            if (dgvThongKe.Columns.Contains("SoPhong"))
                dgvThongKe.Columns["SoPhong"].HeaderText =
                    "Số phòng";

            if (dgvThongKe.Columns.Contains("TenKhuVuc"))
                dgvThongKe.Columns["TenKhuVuc"].HeaderText =
                    "Khu vực";

            if (dgvThongKe.Columns.Contains("SoNguoiToiDa"))
                dgvThongKe.Columns["SoNguoiToiDa"].HeaderText =
                    "Sức chứa";

            if (dgvThongKe.Columns.Contains("DonGiaNgay"))
                dgvThongKe.Columns["DonGiaNgay"].HeaderText =
                    "Đơn giá/ngày";

            if (dgvThongKe.Columns.Contains("TrangThai"))
                dgvThongKe.Columns["TrangThai"].HeaderText =
                    "Trạng thái";

            if (dgvThongKe.Columns.Contains("DonGiaNgay"))
                dgvThongKe.Columns["DonGiaNgay"]
                    .DefaultCellStyle.Format = "N0";

            dgvThongKe.ReadOnly = true;

            dgvThongKe.AllowUserToAddRows = false;
            dgvThongKe.AllowUserToDeleteRows = false;

            dgvThongKe.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvThongKe.MultiSelect = false;

            dgvThongKe.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnLamMoi_Click(
            object sender,
            EventArgs e)
        {
            LoadThongKe();
        }

        private void btnDong_Click(
            object sender,
            EventArgs e)
        {
            Close();
        }
    }
}