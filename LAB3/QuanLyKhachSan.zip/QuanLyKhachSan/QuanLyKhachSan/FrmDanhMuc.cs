﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmDanhMuc : Form
    {
        private DataGridView dgvNhanVien;
        private DataGridView dgvLoaiTienNghi;
        private DataGridView dgvDichVu;
        private DataGridView dgvQuyDinhDenBu;

        public FrmDanhMuc()
        {
            InitializeComponent();

            // Khi mở Form thì tự động tải dữ liệu
            this.Load += FrmDanhMuc_Load;
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            TaoGiaoDienCacTab();
            TaiDuLieuKhuVuc();
            TaiDuLieuNhanVien();
            TaiDuLieuLoaiTienNghi();
            TaiDuLieuDichVu();
            TaiDuLieuQuyDinhDenBu();
        }

        // =========================================================
        // TẠO BẢNG CHO CÁC TAB
        // =========================================================

        private void TaoGiaoDienCacTab()
        {
            // Nhân viên
            dgvNhanVien = TaoDataGridView();
            dgvNhanVien.Location = new Point(25, 115);
            dgvNhanVien.Size = new Size(895, 285);
            tabNhanVien.Controls.Add(dgvNhanVien);

            // Loại tiện nghi
            dgvLoaiTienNghi = TaoDataGridView();
            dgvLoaiTienNghi.Location = new Point(25, 115);
            dgvLoaiTienNghi.Size = new Size(895, 285);
            tabLoaiTienNghi.Controls.Add(dgvLoaiTienNghi);

            // Dịch vụ
            dgvDichVu = TaoDataGridView();
            dgvDichVu.Location = new Point(25, 115);
            dgvDichVu.Size = new Size(895, 285);
            tabDichVu.Controls.Add(dgvDichVu);

            // Quy định đền bù
            dgvQuyDinhDenBu = TaoDataGridView();
            dgvQuyDinhDenBu.Location = new Point(25, 115);
            dgvQuyDinhDenBu.Size = new Size(895, 285);
            tabQuyDinhDenBu.Controls.Add(dgvQuyDinhDenBu);
        }

        private DataGridView TaoDataGridView()
        {
            DataGridView dgv = new DataGridView();

            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToResizeRows = false;

            dgv.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgv.BackgroundColor = Color.White;
            dgv.ReadOnly = true;
            dgv.MultiSelect = false;
            dgv.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgv.RowHeadersVisible = false;
            dgv.RowTemplate.Height = 35;

            dgv.AutoGenerateColumns = true;

            return dgv;
        }

        // =========================================================
        // KHU VỰC
        // =========================================================

        private void TaiDuLieuKhuVuc()
        {
            string sql = @"
                SELECT 
                    MaKhuVuc AS [Mã],
                    TenKhuVuc AS [Tên]
                FROM KhuVuc
                ORDER BY MaKhuVuc";

            DataTable dt = ThucHienTruyVan(sql);

            dgvDanhMuc.AutoGenerateColumns = true;
            dgvDanhMuc.Columns.Clear();
            dgvDanhMuc.DataSource = dt;
        }

        // =========================================================
        // NHÂN VIÊN
        // =========================================================

        private void TaiDuLieuNhanVien()
        {
            string sql = @"
                SELECT
                    MaNV AS [Mã],
                    HoTen AS [Họ tên],
                    VaiTro AS [Vai trò],
                    SoDienThoai AS [Điện thoại]
                FROM NhanVien
                ORDER BY MaNV";

            DataTable dt = ThucHienTruyVan(sql);

            dgvNhanVien.DataSource = dt;
        }

        // =========================================================
        // LOẠI TIỆN NGHI
        // =========================================================

        private void TaiDuLieuLoaiTienNghi()
        {
            string sql = @"
                SELECT
                    MaLoaiTN AS [Mã],
                    TenLoaiTN AS [Tên]
                FROM LoaiTienNghi
                ORDER BY MaLoaiTN";

            DataTable dt = ThucHienTruyVan(sql);

            dgvLoaiTienNghi.DataSource = dt;
        }

        // =========================================================
        // DỊCH VỤ
        // =========================================================

        private void TaiDuLieuDichVu()
        {
            string sql = @"
                SELECT
                    MaDV AS [Mã],
                    TenDV AS [Tên],
                    DonViTinh AS [Đơn vị],
                    DonGia AS [Đơn giá]
                FROM DichVu
                ORDER BY MaDV";

            DataTable dt = ThucHienTruyVan(sql);

            dgvDichVu.DataSource = dt;
        }

        // =========================================================
        // QUY ĐỊNH ĐỀN BÙ
        // =========================================================

        private void TaiDuLieuQuyDinhDenBu()
        {
            string sql = @"
                SELECT
                    MaQuyDinh AS [Mã],
                    MaLoaiTN AS [Mã loại],
                    MucDoThietHai AS [Mức độ thiệt hại],
                    MucDenBu AS [Mức đền bù]
                FROM QuyDinhDenBu
                ORDER BY MaQuyDinh";

            DataTable dt = ThucHienTruyVan(sql);

            dgvQuyDinhDenBu.DataSource = dt;
        }

        // =========================================================
        // HÀM CHẠY SELECT
        // =========================================================

        private DataTable ThucHienTruyVan(string sql)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection cn = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(sql, cn))
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    cn.Open();
                    da.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải dữ liệu:\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

            return dt;
        }

        // =========================================================
        // NÚT THÊM
        // =========================================================

        private void btnThem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Chức năng thêm dữ liệu sẽ được thực hiện ở bước tiếp theo.",
                "Danh mục",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // =========================================================
        // ĐỔI TAB
        // =========================================================

        private void tabDanhMuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabDanhMuc.SelectedTab == null)
                return;

            string tenTab = tabDanhMuc.SelectedTab.Text;

            lblTieuDeDanhMuc.Text = tenTab;

            if (tenTab == "Khu vực")
            {
                lblDonViVaiTro.Text = "Sức chứa:";
            }
            else if (tenTab == "Nhân viên")
            {
                lblDonViVaiTro.Text = "Vai trò:";
            }
            else if (tenTab == "Loại tiện nghi")
            {
                lblDonViVaiTro.Text = "Mã loại:";
            }
            else if (tenTab == "Dịch vụ")
            {
                lblDonViVaiTro.Text = "Đơn vị:";
            }
            else if (tenTab == "Quy định đền bù")
            {
                lblDonViVaiTro.Text = "Mức đền bù:";
            }
        }
    }
}