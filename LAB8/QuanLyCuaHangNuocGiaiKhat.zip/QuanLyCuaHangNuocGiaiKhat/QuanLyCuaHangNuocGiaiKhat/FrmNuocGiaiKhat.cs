﻿
using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using QuanLyCuaHangNuocGiaiKhat.Service;

namespace QuanLyCuaHangNuocGiaiKhat
{
    public partial class FrmNuocGiaiKhat : Form
    {
        private readonly NuocGiaiKhatService service =
            new NuocGiaiKhatService();

        private TextBox txtMa;
        private TextBox txtTen;
        private TextBox txtDonViTinh;
        private TextBox txtSoLuongTon;
        private TextBox txtDonGia;
        private TextBox txtTimKiem;

        private ComboBox cboNhanHieu;
        private ComboBox cboNhaCungUng;
        private DataGridView dgvNuocGiaiKhat;

        public FrmNuocGiaiKhat()
        {
            InitializeComponent();
            TaoGiaoDien();
            Load += FrmNuocGiaiKhat_Load;
        }

        private void TaoGiaoDien()
        {
            Controls.Clear();

            Text = "Quản lý nước giải khát";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1200, 750);
            MinimumSize = new Size(1000, 650);
            BackColor = Color.FromArgb(245, 247, 250);

            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };

            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 190));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            Label lblTieuDe = new Label
            {
                Text = "QUẢN LÝ NƯỚC GIẢI KHÁT",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 21, FontStyle.Bold),
                ForeColor = Color.FromArgb(36, 70, 110)
            };

            layout.Controls.Add(lblTieuDe, 0, 0);

            TableLayoutPanel pnlNhap = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 3,
                Padding = new Padding(20, 10, 20, 10),
                BackColor = Color.White,
                Margin = new Padding(0)
            };

            pnlNhap.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
            pnlNhap.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            pnlNhap.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
            pnlNhap.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            for (int i = 0; i < 3; i++)
                pnlNhap.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33f));

            txtMa = TaoTextBox();
            txtTen = TaoTextBox();
            txtDonViTinh = TaoTextBox();
            txtSoLuongTon = TaoTextBox();
            txtDonGia = TaoTextBox();

            cboNhanHieu = new ComboBox
            {
                Dock = DockStyle.Fill,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Arial", 10),
                Margin = new Padding(5, 8, 12, 8)
            };

            cboNhaCungUng = new ComboBox
            {
                Dock = DockStyle.Fill,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Arial", 10),
                Margin = new Padding(5, 8, 12, 8)
            };

            ThemTruong(pnlNhap, "Mã sản phẩm:", txtMa, 0, 0);
            ThemTruong(pnlNhap, "Tên sản phẩm:", txtTen, 2, 0);
            ThemTruong(pnlNhap, "Đơn vị tính:", txtDonViTinh, 0, 1);
            ThemTruong(pnlNhap, "Nhãn hiệu:", cboNhanHieu, 2, 1);
            ThemTruong(pnlNhap, "Nhà cung ứng:", cboNhaCungUng, 0, 2);

            FlowLayoutPanel pnlSoLieu = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                WrapContents = false,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0)
            };

            pnlSoLieu.Controls.Add(new Label
            {
                Text = "Tồn:",
                Width = 45,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(0, 8, 0, 0)
            });

            txtSoLuongTon.Width = 85;
            pnlSoLieu.Controls.Add(txtSoLuongTon);

            pnlSoLieu.Controls.Add(new Label
            {
                Text = "Đơn giá:",
                Width = 65,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(5, 8, 0, 0)
            });

            txtDonGia.Width = 130;
            pnlSoLieu.Controls.Add(txtDonGia);

            ThemTruong(pnlNhap, "Thông tin kho:", pnlSoLieu, 2, 2);

            layout.Controls.Add(pnlNhap, 0, 1);

            FlowLayoutPanel pnlNut = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(10, 8, 5, 5),
                Margin = new Padding(0),
                AutoScroll = true
            };

            ThemNut(pnlNut, "Thêm", Color.FromArgb(36, 92, 60), BtnThem_Click);
            ThemNut(pnlNut, "Sửa", Color.FromArgb(40, 110, 180), BtnSua_Click);
            ThemNut(pnlNut, "Xóa", Color.FromArgb(190, 55, 55), BtnXoa_Click);
            ThemNut(pnlNut, "Làm mới", Color.Gray, BtnLamMoi_Click);

            txtTimKiem = new TextBox
            {
                Width = 220,
                Font = new Font("Arial", 10),
                Margin = new Padding(15, 5, 5, 5)
            };

            pnlNut.Controls.Add(txtTimKiem);

            Button btnTim = new Button
            {
                Text = "Tìm kiếm",
                Width = 100,
                Height = 32,
                BackColor = Color.FromArgb(36, 70, 110),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(5)
            };

            btnTim.FlatAppearance.BorderSize = 0;
            btnTim.Click += BtnTim_Click;
            pnlNut.Controls.Add(btnTim);

            layout.Controls.Add(pnlNut, 0, 2);

            dgvNuocGiaiKhat = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoGenerateColumns = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                RowHeadersVisible = false,
                Margin = new Padding(10)
            };

            dgvNuocGiaiKhat.CellClick += DgvNuocGiaiKhat_CellClick;
            layout.Controls.Add(dgvNuocGiaiKhat, 0, 3);

            Controls.Add(layout);
        }

        private TextBox TaoTextBox()
        {
            return new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Arial", 10),
                Margin = new Padding(5, 8, 12, 8)
            };
        }

        private Label TaoNhan(string noiDung)
        {
            return new Label
            {
                Text = noiDung,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Arial", 10),
                Margin = new Padding(5)
            };
        }

        private void ThemTruong(
            TableLayoutPanel panel,
            string nhan,
            Control control,
            int cot,
            int hang)
        {
            panel.Controls.Add(TaoNhan(nhan), cot, hang);
            panel.Controls.Add(control, cot + 1, hang);
        }

        private void ThemNut(
            FlowLayoutPanel panel,
            string noiDung,
            Color mau,
            EventHandler suKien)
        {
            Button btn = new Button
            {
                Text = noiDung,
                Width = 95,
                Height = 32,
                BackColor = mau,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Arial", 10),
                Margin = new Padding(5)
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.Click += suKien;
            panel.Controls.Add(btn);
        }

        private void FrmNuocGiaiKhat_Load(object sender, EventArgs e)
        {
            try
            {
                cboNhanHieu.DataSource = service.LayDanhSachNhanHieu();
                cboNhanHieu.DisplayMember = "TenNhanHieu";
                cboNhanHieu.ValueMember = "MaNhanHieu";

                cboNhaCungUng.DataSource = service.LayDanhSachNhaCungUng();
                cboNhaCungUng.DisplayMember = "TenNCC";
                cboNhaCungUng.ValueMember = "MaNCC";

                TaiDanhSach();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không tải được dữ liệu nước giải khát, nhãn hiệu hoặc nhà cung ứng.\n\n"
                    + ex.Message,
                    "Lỗi tải dữ liệu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void TaiDanhSach(string tuKhoa = "")
        {
            try
            {
                dgvNuocGiaiKhat.DataSource = service.LayDanhSach(tuKhoa);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách: " + ex.Message);
            }
        }

        private string MaDangChon(ComboBox cbo)
        {
            return cbo.SelectedValue == null ||
                   cbo.SelectedValue is DataRowView
                ? ""
                : cbo.SelectedValue.ToString();
        }

        private void LayThongTin(
            out string ma,
            out string ten,
            out string donVi,
            out string maNhanHieu,
            out string maNCC,
            out int ton,
            out decimal gia)
        {
            ma = txtMa.Text.Trim();
            ten = txtTen.Text.Trim();
            donVi = txtDonViTinh.Text.Trim();
            maNhanHieu = MaDangChon(cboNhanHieu);
            maNCC = MaDangChon(cboNhaCungUng);

            if (!int.TryParse(txtSoLuongTon.Text.Trim(), out ton))
                throw new Exception("Số lượng tồn phải là số nguyên.");

            if (!decimal.TryParse(
                txtDonGia.Text.Trim(),
                NumberStyles.Number,
                CultureInfo.CurrentCulture,
                out gia))
            {
                throw new Exception("Đơn giá không hợp lệ.");
            }
        }

        private void BtnThem_Click(object sender, EventArgs e)
        {
            try
            {
                LayThongTin(
                    out string ma, out string ten, out string donVi,
                    out string maNhanHieu, out string maNCC,
                    out int ton, out decimal gia);

                service.Them(
                    ma, ten, donVi, maNhanHieu, maNCC, ton, gia);

                MessageBox.Show("Thêm nước giải khát thành công!");
                TaiDanhSach();
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Không thể thêm sản phẩm");
            }
        }

        private void BtnSua_Click(object sender, EventArgs e)
        {
            try
            {
                LayThongTin(
                    out string ma, out string ten, out string donVi,
                    out string maNhanHieu, out string maNCC,
                    out int ton, out decimal gia);

                service.CapNhat(
                    ma, ten, donVi, maNhanHieu, maNCC, ton, gia);

                MessageBox.Show("Cập nhật nước giải khát thành công!");
                TaiDanhSach();
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Không thể cập nhật sản phẩm");
            }
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMa.Text))
            {
                MessageBox.Show("Vui lòng chọn sản phẩm cần xóa.");
                return;
            }

            if (MessageBox.Show(
                "Bạn có chắc muốn xóa sản phẩm này không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                service.Xoa(txtMa.Text.Trim());
                MessageBox.Show("Xóa sản phẩm thành công!");
                TaiDanhSach();
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể xóa sản phẩm.\n" + ex.Message);
            }
        }

        private void BtnLamMoi_Click(object sender, EventArgs e)
        {
            XoaTrang();
            TaiDanhSach();
        }

        private void BtnTim_Click(object sender, EventArgs e)
        {
            TaiDanhSach(txtTimKiem.Text.Trim());
        }

        private void DgvNuocGiaiKhat_CellClick(
            object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row = dgvNuocGiaiKhat.Rows[e.RowIndex];

            txtMa.Text = GiaTri(row, "MaNGK");
            txtTen.Text = GiaTri(row, "TenNGK");
            txtDonViTinh.Text = GiaTri(row, "DonViTinh");
            txtSoLuongTon.Text = GiaTri(row, "SoLuongTon");
            txtDonGia.Text = GiaTri(row, "DonGia");

            ChonCombo(cboNhanHieu, GiaTri(row, "MaNhanHieu"));
            ChonCombo(cboNhaCungUng, GiaTri(row, "MaNCC"));
        }

        private string GiaTri(DataGridViewRow row, string tenCot)
        {
            if (!dgvNuocGiaiKhat.Columns.Contains(tenCot))
                return "";

            object value = row.Cells[tenCot].Value;

            return value == null || value == DBNull.Value
                ? ""
                : value.ToString();
        }

        private void ChonCombo(ComboBox cbo, string ma)
        {
            if (cbo.DataSource == null)
                return;

            cbo.SelectedValue = ma;

            if (cbo.SelectedIndex < 0)
                cbo.SelectedIndex = -1;
        }

        private void XoaTrang()
        {
            txtMa.Clear();
            txtTen.Clear();
            txtDonViTinh.Clear();
            txtSoLuongTon.Clear();
            txtDonGia.Clear();
            txtTimKiem.Clear();

            if (cboNhanHieu.Items.Count > 0)
                cboNhanHieu.SelectedIndex = 0;

            if (cboNhaCungUng.Items.Count > 0)
                cboNhaCungUng.SelectedIndex = 0;

            txtMa.Focus();
        }
    }
}
