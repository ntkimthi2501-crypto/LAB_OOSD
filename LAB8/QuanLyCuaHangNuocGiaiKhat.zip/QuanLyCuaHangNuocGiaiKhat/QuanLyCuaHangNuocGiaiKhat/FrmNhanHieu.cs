﻿
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyCuaHangNuocGiaiKhat.Service;

namespace QuanLyCuaHangNuocGiaiKhat
{
    public partial class FrmNhanHieu : Form
    {
        private readonly NhanHieuService service = new NhanHieuService();

        private TextBox txtMa;
        private TextBox txtTen;
        private TextBox txtTimKiem;
        private DataGridView dgvNhanHieu;

        private readonly Color mauXanh = Color.FromArgb(40, 105, 158);
        private readonly Color mauNen = Color.FromArgb(239, 245, 249);

        public FrmNhanHieu()
        {
            TaoGiaoDien();
            Load += FrmNhanHieu_Load;
        }

        private void TaoGiaoDien()
        {
            Text = "Quản lý nhãn hiệu";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(900, 600);
            MinimumSize = new Size(750, 500);
            BackColor = mauNen;
            Font = new Font("Segoe UI", 10F);

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "QUẢN LÝ NHÃN HIỆU";
            lblTieuDe.Dock = DockStyle.Top;
            lblTieuDe.Height = 65;
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            lblTieuDe.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.FromArgb(35, 79, 119);

            Panel pnlNhap = new Panel();
            pnlNhap.Dock = DockStyle.Top;
            pnlNhap.Height = 115;
            pnlNhap.Padding = new Padding(25, 10, 25, 5);
            pnlNhap.BackColor = mauNen;

            Label lblMa = new Label();
            lblMa.Text = "Mã nhãn hiệu:";
            lblMa.Location = new Point(25, 15);
            lblMa.AutoSize = true;

            txtMa = new TextBox();
            txtMa.Name = "txtMa";
            txtMa.Location = new Point(155, 12);
            txtMa.Width = 230;
            txtMa.MaxLength = 10;

            Label lblTen = new Label();
            lblTen.Text = "Tên nhãn hiệu:";
            lblTen.Location = new Point(25, 55);
            lblTen.AutoSize = true;

            txtTen = new TextBox();
            txtTen.Name = "txtTen";
            txtTen.Location = new Point(155, 52);
            txtTen.Width = 400;
            txtTen.MaxLength = 100;

            pnlNhap.Controls.Add(lblMa);
            pnlNhap.Controls.Add(txtMa);
            pnlNhap.Controls.Add(lblTen);
            pnlNhap.Controls.Add(txtTen);

            FlowLayoutPanel pnlNut = new FlowLayoutPanel();
            pnlNut.Dock = DockStyle.Top;
            pnlNut.Height = 50;
            pnlNut.Padding = new Padding(20, 3, 10, 3);
            pnlNut.BackColor = mauNen;
            pnlNut.WrapContents = false;

            ThemNut(pnlNut, "Thêm", BtnThem_Click);
            ThemNut(pnlNut, "Sửa", BtnSua_Click);
            ThemNut(pnlNut, "Xóa", BtnXoa_Click);
            ThemNut(pnlNut, "Làm mới", BtnLamMoi_Click);

            Label lblTim = new Label();
            lblTim.Text = "Tìm kiếm:";
            lblTim.Dock = DockStyle.Top;
            lblTim.Height = 28;
            lblTim.Padding = new Padding(25, 4, 0, 0);

            Panel pnlTim = new Panel();
            pnlTim.Dock = DockStyle.Top;
            pnlTim.Height = 43;
            pnlTim.Padding = new Padding(25, 2, 25, 5);

            txtTimKiem = new TextBox();
            txtTimKiem.Dock = DockStyle.Fill;
            txtTimKiem.Name = "txtTimKiem";

            Button btnTim = new Button();
            btnTim.Text = "Tìm";
            btnTim.Dock = DockStyle.Right;
            btnTim.Width = 90;
            btnTim.BackColor = mauXanh;
            btnTim.ForeColor = Color.White;
            btnTim.FlatStyle = FlatStyle.Flat;
            btnTim.FlatAppearance.BorderSize = 0;
            btnTim.Click += BtnTim_Click;

            pnlTim.Controls.Add(txtTimKiem);
            pnlTim.Controls.Add(btnTim);

            dgvNhanHieu = new DataGridView();
            dgvNhanHieu.Name = "dgvNhanHieu";
            dgvNhanHieu.Dock = DockStyle.Fill;
            dgvNhanHieu.BackgroundColor = Color.White;
            dgvNhanHieu.BorderStyle = BorderStyle.None;
            dgvNhanHieu.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            dgvNhanHieu.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvNhanHieu.MultiSelect = false;
            dgvNhanHieu.ReadOnly = true;
            dgvNhanHieu.AllowUserToAddRows = false;
            dgvNhanHieu.AllowUserToDeleteRows = false;
            dgvNhanHieu.RowHeadersVisible = false;
            dgvNhanHieu.AutoGenerateColumns = true;
            dgvNhanHieu.CellClick += DgvNhanHieu_CellClick;

            // Them control theo thu tu tu duoi len
            Controls.Add(dgvNhanHieu);
            Controls.Add(pnlTim);
            Controls.Add(lblTim);
            Controls.Add(pnlNut);
            Controls.Add(pnlNhap);
            Controls.Add(lblTieuDe);
        }

        private void ThemNut(
            FlowLayoutPanel panel,
            string ten,
            EventHandler suKien)
        {
            Button btn = new Button();
            btn.Text = ten;
            btn.Width = 105;
            btn.Height = 35;
            btn.Margin = new Padding(5, 3, 5, 3);
            btn.BackColor = mauXanh;
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Cursor = Cursors.Hand;
            btn.Click += suKien;
            panel.Controls.Add(btn);
        }

        private void FrmNhanHieu_Load(object sender, EventArgs e)
        {
            TaiDanhSach("");
        }

        private void TaiDanhSach(string tuKhoa)
        {
            try
            {
                dgvNhanHieu.DataSource =
                    service.LayDanhSach(tuKhoa);

                if (dgvNhanHieu.Columns["MaNhanHieu"] != null)
                    dgvNhanHieu.Columns["MaNhanHieu"].HeaderText =
                        "Mã nhãn hiệu";

                if (dgvNhanHieu.Columns["TenNhanHieu"] != null)
                    dgvNhanHieu.Columns["TenNhanHieu"].HeaderText =
                        "Tên nhãn hiệu";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải danh sách nhãn hiệu.\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnThem_Click(object sender, EventArgs e)
        {
            try
            {
                service.Them(txtMa.Text, txtTen.Text);
                MessageBox.Show("Thêm nhãn hiệu thành công!");
                TaiDanhSach(txtTimKiem.Text);
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể thêm nhãn hiệu.\n" + ex.Message,
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void BtnSua_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMa.Text))
                {
                    MessageBox.Show("Vui lòng chọn nhãn hiệu cần sửa.");
                    return;
                }

                service.CapNhat(txtMa.Text, txtTen.Text);
                MessageBox.Show("Cập nhật nhãn hiệu thành công!");
                TaiDanhSach(txtTimKiem.Text);
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể cập nhật nhãn hiệu.\n" + ex.Message,
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMa.Text))
            {
                MessageBox.Show("Vui lòng chọn nhãn hiệu cần xóa.");
                return;
            }

            DialogResult ketQua = MessageBox.Show(
                "Bạn có chắc muốn xóa nhãn hiệu này?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (ketQua != DialogResult.Yes)
                return;

            try
            {
                service.Xoa(txtMa.Text);
                MessageBox.Show("Xóa nhãn hiệu thành công!");
                TaiDanhSach(txtTimKiem.Text);
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể xóa nhãn hiệu.\n" +
                    "Có thể nhãn hiệu đang được sản phẩm sử dụng.\n\n" +
                    ex.Message,
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void BtnLamMoi_Click(object sender, EventArgs e)
        {
            XoaTrang();
            txtTimKiem.Clear();
            TaiDanhSach("");
        }

        private void BtnTim_Click(object sender, EventArgs e)
        {
            TaiDanhSach(txtTimKiem.Text);
        }

        private void DgvNhanHieu_CellClick(
            object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row = dgvNhanHieu.Rows[e.RowIndex];

            txtMa.Text =
                Convert.ToString(row.Cells["MaNhanHieu"].Value);

            txtTen.Text =
                Convert.ToString(row.Cells["TenNhanHieu"].Value);
        }

        private void XoaTrang()
        {
            txtMa.Clear();
            txtTen.Clear();
            txtMa.Focus();
        }
    }
}
