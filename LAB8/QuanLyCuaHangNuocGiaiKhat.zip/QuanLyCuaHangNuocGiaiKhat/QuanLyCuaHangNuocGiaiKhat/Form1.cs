﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyCuaHangNuocGiaiKhat
{
    public partial class Form1 : Form
    {
        private Label lblTieuDe;
        private Label lblPhuDe;

        private Button btnNhanHieu;
        private Button btnNhaCungUng;
        private Button btnNuocGiaiKhat;
        private Button btnNhapHang;
        private Button btnBanHang;
        private Button btnPhieuHenGiao;
        private Button btnKhachHang;
        private Button btnPhieuGhiNo;

        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            Controls.Clear();

            Text = "Quản lý cửa hàng nước giải khát";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1000, 700);
            MinimumSize = new Size(900, 600);
            BackColor = Color.FromArgb(238, 243, 248);
            Font = new Font("Arial", 10);

            // Tiêu đề chính
            lblTieuDe = new Label
            {
                Name = "lblTieuDe",
                Text = "QUẢN LÝ CỬA HÀNG NƯỚC GIẢI KHÁT",
                Font = new Font("Arial", 23, FontStyle.Bold),
                ForeColor = Color.FromArgb(36, 70, 110),
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 100
            };

            // Tiêu đề phụ
            lblPhuDe = new Label
            {
                Name = "lblPhuDe",
                Text = "HỆ THỐNG QUẢN LÝ KINH DOANH",
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.FromArgb(90, 105, 120),
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 45
            };

            // Khu vực chứa các nút chức năng
            TableLayoutPanel pnlChucNang = new TableLayoutPanel
            {
                Name = "pnlChucNang",
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 4,
                Padding = new Padding(70, 35, 70, 45),
                BackColor = Color.FromArgb(238, 243, 248)
            };

            pnlChucNang.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 50));

            pnlChucNang.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 50));

            for (int i = 0; i < 4; i++)
            {
                pnlChucNang.RowStyles.Add(
                    new RowStyle(SizeType.Percent, 25));
            }

            // Tạo nút chức năng
            btnNhanHieu = TaoNut("NHÃN HIỆU", "btnNhanHieu");
            btnNhaCungUng = TaoNut("NHÀ CUNG ỨNG", "btnNhaCungUng");
            btnNuocGiaiKhat = TaoNut("NƯỚC GIẢI KHÁT", "btnNuocGiaiKhat");
            btnNhapHang = TaoNut("NHẬP HÀNG", "btnNhapHang");
            btnBanHang = TaoNut("BÁN HÀNG", "btnBanHang");
            btnPhieuHenGiao = TaoNut("PHIẾU HẸN GIAO", "btnPhieuHenGiao");
            btnKhachHang = TaoNut("KHÁCH HÀNG", "btnKhachHang");
            btnPhieuGhiNo = TaoNut("PHIẾU GHI NỢ", "btnPhieuGhiNo");

            // Sắp xếp thành 2 cột, 4 hàng
            pnlChucNang.Controls.Add(btnNhanHieu, 0, 0);
            pnlChucNang.Controls.Add(btnNhaCungUng, 1, 0);

            pnlChucNang.Controls.Add(btnNuocGiaiKhat, 0, 1);
            pnlChucNang.Controls.Add(btnNhapHang, 1, 1);

            pnlChucNang.Controls.Add(btnBanHang, 0, 2);
            pnlChucNang.Controls.Add(btnPhieuHenGiao, 1, 2);

            pnlChucNang.Controls.Add(btnKhachHang, 0, 3);
            pnlChucNang.Controls.Add(btnPhieuGhiNo, 1, 3);

            // Thêm control vào form
            Controls.Add(pnlChucNang);
            Controls.Add(lblPhuDe);
            Controls.Add(lblTieuDe);
        }

        private Button TaoNut(string noiDung, string tenNut)
        {
            Button btn = new Button
            {
                Name = tenNut,
                Text = noiDung,
                Dock = DockStyle.Fill,
                Margin = new Padding(12),
                BackColor = Color.FromArgb(45, 100, 155),
                ForeColor = Color.White,
                Font = new Font("Arial", 12, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.Click += BtnChucNang_Click;

            return btn;
        }

        private void BtnChucNang_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            if (btn == null)
                return;

            // 1. Quản lý nhãn hiệu
            if (btn.Name == "btnNhanHieu")
            {
                using (FrmNhanHieu frm = new FrmNhanHieu())
                {
                    frm.ShowDialog(this);
                }

                return;
            }

            // 2. Quản lý nhà cung ứng
            if (btn.Name == "btnNhaCungUng")
            {
                using (FrmNhaCungUng frm = new FrmNhaCungUng())
                {
                    frm.ShowDialog(this);
                }

                return;
            }

            // 3. Quản lý nước giải khát
            if (btn.Name == "btnNuocGiaiKhat")
            {
                using (FrmNuocGiaiKhat frm = new FrmNuocGiaiKhat())
                {
                    frm.ShowDialog(this);
                }

                return;
            }

            // Các chức năng sẽ làm ở những bước tiếp theo
            MessageBox.Show(
                "Chức năng " + btn.Text +
                " sẽ được hoàn thiện ở bước tiếp theo nha!",
                "Thông báo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}
