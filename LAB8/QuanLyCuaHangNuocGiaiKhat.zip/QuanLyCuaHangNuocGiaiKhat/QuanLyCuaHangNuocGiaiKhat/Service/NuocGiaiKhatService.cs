﻿
using System;
using System.Data;
using QuanLyCuaHangNuocGiaiKhat.Data;

namespace QuanLyCuaHangNuocGiaiKhat.Service
{
    public class NuocGiaiKhatService
    {
        private readonly NuocGiaiKhatData data =
            new NuocGiaiKhatData();

        public DataTable LayDanhSach(string tuKhoa = "")
        {
            return data.LayDanhSach(tuKhoa);
        }

        public DataTable LayDanhSachNhanHieu()
        {
            return data.LayDanhSachNhanHieu();
        }

        public DataTable LayDanhSachNhaCungUng()
        {
            return data.LayDanhSachNhaCungUng();
        }

        public void Them(
            string ma,
            string ten,
            string donViTinh,
            string maNhanHieu,
            string maNCC,
            int soLuongTon,
            decimal donGia)
        {
            KiemTraDuLieu(
                ma, ten, donViTinh,
                maNhanHieu, maNCC, soLuongTon, donGia);

            data.Them(
                ma, ten, donViTinh,
                maNhanHieu, maNCC, soLuongTon, donGia);
        }

        public void CapNhat(
            string ma,
            string ten,
            string donViTinh,
            string maNhanHieu,
            string maNCC,
            int soLuongTon,
            decimal donGia)
        {
            KiemTraDuLieu(
                ma, ten, donViTinh,
                maNhanHieu, maNCC, soLuongTon, donGia);

            data.CapNhat(
                ma, ten, donViTinh,
                maNhanHieu, maNCC, soLuongTon, donGia);
        }

        public void Xoa(string ma)
        {
            if (string.IsNullOrWhiteSpace(ma))
                throw new Exception("Vui lòng chọn nước giải khát cần xóa.");

            data.Xoa(ma);
        }

        private void KiemTraDuLieu(
            string ma,
            string ten,
            string donViTinh,
            string maNhanHieu,
            string maNCC,
            int soLuongTon,
            decimal donGia)
        {
            if (string.IsNullOrWhiteSpace(ma))
                throw new Exception("Vui lòng nhập mã nước giải khát.");

            if (string.IsNullOrWhiteSpace(ten))
                throw new Exception("Vui lòng nhập tên nước giải khát.");

            if (string.IsNullOrWhiteSpace(donViTinh))
                throw new Exception("Vui lòng nhập đơn vị tính.");

            if (string.IsNullOrWhiteSpace(maNhanHieu))
                throw new Exception("Vui lòng chọn nhãn hiệu.");

            if (string.IsNullOrWhiteSpace(maNCC))
                throw new Exception("Vui lòng chọn nhà cung ứng.");

            if (soLuongTon < 0)
                throw new Exception("Số lượng tồn không được âm.");

            if (donGia < 0)
                throw new Exception("Đơn giá không được âm.");
        }
    }
}
