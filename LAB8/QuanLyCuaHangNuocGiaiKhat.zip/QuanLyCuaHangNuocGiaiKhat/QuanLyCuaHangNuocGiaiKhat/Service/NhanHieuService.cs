﻿
using System;
using System.Data;
using QuanLyCuaHangNuocGiaiKhat.Data;

namespace QuanLyCuaHangNuocGiaiKhat.Service
{
    public class NhanHieuService
    {
        private readonly NhanHieuData data = new NhanHieuData();

        public DataTable LayDanhSach(string tuKhoa)
        {
            return data.LayDanhSach(tuKhoa);
        }

        public void Them(string ma, string ten)
        {
            KiemTraDuLieu(ma, ten);
            data.Them(ma.Trim(), ten.Trim());
        }

        public void CapNhat(string ma, string ten)
        {
            KiemTraDuLieu(ma, ten);
            data.CapNhat(ma.Trim(), ten.Trim());
        }

        public void Xoa(string ma)
        {
            if (string.IsNullOrWhiteSpace(ma))
                throw new ArgumentException(
                    "Vui lòng chọn nhãn hiệu cần xóa.");

            data.Xoa(ma.Trim());
        }

        private void KiemTraDuLieu(string ma, string ten)
        {
            if (string.IsNullOrWhiteSpace(ma))
                throw new ArgumentException(
                    "Mã nhãn hiệu không được để trống.");

            if (string.IsNullOrWhiteSpace(ten))
                throw new ArgumentException(
                    "Tên nhãn hiệu không được để trống.");

            if (ma.Trim().Length > 10)
                throw new ArgumentException(
                    "Mã nhãn hiệu tối đa 10 ký tự.");

            if (ten.Trim().Length > 100)
                throw new ArgumentException(
                    "Tên nhãn hiệu tối đa 100 ký tự.");
        }
    }
}
