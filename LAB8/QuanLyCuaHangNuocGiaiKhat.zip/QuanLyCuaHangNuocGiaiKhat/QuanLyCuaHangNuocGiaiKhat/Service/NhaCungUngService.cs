﻿
using System;
using System.Data;
using QuanLyCuaHangNuocGiaiKhat.Data;

namespace QuanLyCuaHangNuocGiaiKhat.Service
{
    public class NhaCungUngService
    {
        private readonly NhaCungUngData data = new NhaCungUngData();

        public DataTable LayDanhSach(string tuKhoa)
        {
            return data.LayDanhSach(tuKhoa);
        }

        public void Them(string ma, string ten, string diaChi, string dienThoai)
        {
            KiemTra(ma, ten, dienThoai);
            data.Them(ma.Trim(), ten.Trim(), diaChi, dienThoai);
        }

        public void CapNhat(string ma, string ten, string diaChi, string dienThoai)
        {
            KiemTra(ma, ten, dienThoai);
            data.CapNhat(ma.Trim(), ten.Trim(), diaChi, dienThoai);
        }

        public void Xoa(string ma)
        {
            if (string.IsNullOrWhiteSpace(ma))
                throw new ArgumentException("Vui lòng chọn nhà cung ứng.");

            data.Xoa(ma.Trim());
        }

        private void KiemTra(string ma, string ten, string dienThoai)
        {
            if (string.IsNullOrWhiteSpace(ma))
                throw new ArgumentException("Mã nhà cung ứng không được để trống.");

            if (string.IsNullOrWhiteSpace(ten))
                throw new ArgumentException("Tên nhà cung ứng không được để trống.");

            if (ma.Trim().Length > 10)
                throw new ArgumentException("Mã nhà cung ứng tối đa 10 ký tự.");

            if (ten.Trim().Length > 150)
                throw new ArgumentException("Tên nhà cung ứng tối đa 150 ký tự.");

            if (!string.IsNullOrWhiteSpace(dienThoai) &&
                dienThoai.Trim().Length > 20)
                throw new ArgumentException("Số điện thoại tối đa 20 ký tự.");
        }
    }
}
