﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCuaHangNuocGiaiKhat.Data
{
    public class NuocGiaiKhatData
    {
        public DataTable LayDanhSach(string tuKhoa = "")
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            {
                string sql = @"
                    SELECT
                        n.MaNGK,
                        n.TenNGK,
                        n.DonViTinh,
                        n.MaNhanHieu,
                        nh.TenNhanHieu,
                        n.MaNCC,
                        n.SoLuongTon,
                        n.DonGia
                    FROM dbo.NuocGiaiKhat n
                    LEFT JOIN dbo.NhanHieu nh
                        ON n.MaNhanHieu = nh.MaNhanHieu
                    WHERE
                        n.MaNGK LIKE @TuKhoa
                        OR n.TenNGK LIKE @TuKhoa
                        OR nh.TenNhanHieu LIKE @TuKhoa
                    ORDER BY n.TenNGK";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add(
                        "@TuKhoa",
                        SqlDbType.NVarChar,
                        200).Value = "%" + tuKhoa + "%";

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public DataTable LayDanhSachNhanHieu()
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            {
                string sql = @"
                    SELECT MaNhanHieu, TenNhanHieu
                    FROM dbo.NhanHieu
                    ORDER BY TenNhanHieu";

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(sql, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable LayDanhSachNhaCungUng()
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            {
                string sql = @"
                    SELECT MaNCC, TenNCC
                    FROM dbo.NhaCungUng
                    ORDER BY TenNCC";

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(sql, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        public void Them(
            string ma,
            string ten,
            string donViTinh,
            string maNhanHieu,
            string maNCC,
            int soLuongTon,
            decimal donGia)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            {
                string sql = @"
                    INSERT INTO dbo.NuocGiaiKhat
                    (
                        MaNGK,
                        TenNGK,
                        DonViTinh,
                        MaNhanHieu,
                        MaNCC,
                        SoLuongTon,
                        DonGia
                    )
                    VALUES
                    (
                        @MaNGK,
                        @TenNGK,
                        @DonViTinh,
                        @MaNhanHieu,
                        @MaNCC,
                        @SoLuongTon,
                        @DonGia
                    )";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    GanThamSo(
                        cmd, ma, ten, donViTinh,
                        maNhanHieu, maNCC, soLuongTon, donGia);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void CapNhat(
            string ma,
            string ten,
            string donViTinh,
            string maNhanHieu,
            string maNCC,
            int soLuongTon,
            decimal donGia)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            {
                string sql = @"
                    UPDATE dbo.NuocGiaiKhat
                    SET
                        TenNGK = @TenNGK,
                        DonViTinh = @DonViTinh,
                        MaNhanHieu = @MaNhanHieu,
                        MaNCC = @MaNCC,
                        SoLuongTon = @SoLuongTon,
                        DonGia = @DonGia
                    WHERE MaNGK = @MaNGK";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    GanThamSo(
                        cmd, ma, ten, donViTinh,
                        maNhanHieu, maNCC, soLuongTon, donGia);

                    conn.Open();

                    int soDong = cmd.ExecuteNonQuery();

                    if (soDong == 0)
                    {
                        throw new Exception(
                            "Không tìm thấy nước giải khát cần cập nhật.");
                    }
                }
            }
        }

        public void Xoa(string ma)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            {
                string sql = @"
                    DELETE FROM dbo.NuocGiaiKhat
                    WHERE MaNGK = @MaNGK";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add(
                        "@MaNGK",
                        SqlDbType.NVarChar,
                        50).Value = ma;

                    conn.Open();

                    int soDong = cmd.ExecuteNonQuery();

                    if (soDong == 0)
                    {
                        throw new Exception(
                            "Không tìm thấy nước giải khát cần xóa.");
                    }
                }
            }
        }

        private void GanThamSo(
            SqlCommand cmd,
            string ma,
            string ten,
            string donViTinh,
            string maNhanHieu,
            string maNCC,
            int soLuongTon,
            decimal donGia)
        {
            cmd.Parameters.Add(
                "@MaNGK", SqlDbType.NVarChar, 50).Value = ma;

            cmd.Parameters.Add(
                "@TenNGK", SqlDbType.NVarChar, 200).Value = ten;

            cmd.Parameters.Add(
                "@DonViTinh", SqlDbType.NVarChar, 50).Value = donViTinh;

            cmd.Parameters.Add(
                "@MaNhanHieu", SqlDbType.NVarChar, 50).Value = maNhanHieu;

            cmd.Parameters.Add(
                "@MaNCC", SqlDbType.NVarChar, 50).Value = maNCC;

            cmd.Parameters.Add(
                "@SoLuongTon", SqlDbType.Int).Value = soLuongTon;

            SqlParameter pDonGia = cmd.Parameters.Add(
                "@DonGia", SqlDbType.Decimal);

            pDonGia.Precision = 18;
            pDonGia.Scale = 2;
            pDonGia.Value = donGia;
        }
    }
}
