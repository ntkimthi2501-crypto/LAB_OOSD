﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCuaHangNuocGiaiKhat.Data
{
    public class NhanHieuData
    {
        public DataTable LayDanhSach(string tuKhoa)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            {
                string sql = @"
                    SELECT MaNhanHieu, TenNhanHieu
                    FROM dbo.NhanHieu
                    WHERE MaNhanHieu LIKE @TuKhoa
                       OR TenNhanHieu LIKE @TuKhoa
                    ORDER BY MaNhanHieu";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@TuKhoa", SqlDbType.NVarChar, 100)
                        .Value = "%" + (tuKhoa ?? "").Trim() + "%";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        return table;
                    }
                }
            }
        }

        public void Them(string ma, string ten)
        {
            string sql = @"
                INSERT INTO dbo.NhanHieu (MaNhanHieu, TenNhanHieu)
                VALUES (@Ma, @Ten)";

            ThucThi(sql, ma, ten);
        }

        public void CapNhat(string ma, string ten)
        {
            string sql = @"
                UPDATE dbo.NhanHieu
                SET TenNhanHieu = @Ten
                WHERE MaNhanHieu = @Ma";

            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@Ma", SqlDbType.VarChar, 10).Value = ma;
                cmd.Parameters.Add("@Ten", SqlDbType.NVarChar, 100).Value = ten;

                conn.Open();

                if (cmd.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException(
                        "Không tìm thấy nhãn hiệu cần cập nhật.");
            }
        }

        public void Xoa(string ma)
        {
            string sql = @"
                DELETE FROM dbo.NhanHieu
                WHERE MaNhanHieu = @Ma";

            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@Ma", SqlDbType.VarChar, 10).Value = ma;

                conn.Open();

                if (cmd.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException(
                        "Không tìm thấy nhãn hiệu cần xóa.");
            }
        }

        private void ThucThi(string sql, string ma, string ten)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@Ma", SqlDbType.VarChar, 10).Value = ma;
                cmd.Parameters.Add("@Ten", SqlDbType.NVarChar, 100).Value = ten;

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
