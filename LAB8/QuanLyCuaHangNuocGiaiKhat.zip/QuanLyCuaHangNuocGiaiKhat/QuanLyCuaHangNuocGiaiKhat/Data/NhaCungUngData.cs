﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCuaHangNuocGiaiKhat.Data
{
    public class NhaCungUngData
    {
        public DataTable LayDanhSach(string tuKhoa)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            using (SqlCommand cmd = new SqlCommand(@"
                SELECT MaNCC, TenNCC, DiaChi, SoDienThoai
                FROM dbo.NhaCungUng
                WHERE MaNCC LIKE @TuKhoa
                   OR TenNCC LIKE @TuKhoa
                   OR DiaChi LIKE @TuKhoa
                   OR SoDienThoai LIKE @TuKhoa
                ORDER BY MaNCC", conn))
            {
                cmd.Parameters.Add("@TuKhoa", SqlDbType.NVarChar, 150)
                    .Value = "%" + (tuKhoa ?? "").Trim() + "%";

                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
            }
        }

        public void Them(string ma, string ten, string diaChi, string dienThoai)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            using (SqlCommand cmd = new SqlCommand(@"
                INSERT INTO dbo.NhaCungUng
                    (MaNCC, TenNCC, DiaChi, SoDienThoai)
                VALUES
                    (@Ma, @Ten, @DiaChi, @DienThoai)", conn))
            {
                GanThamSo(cmd, ma, ten, diaChi, dienThoai);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void CapNhat(string ma, string ten, string diaChi, string dienThoai)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            using (SqlCommand cmd = new SqlCommand(@"
                UPDATE dbo.NhaCungUng
                SET TenNCC = @Ten,
                    DiaChi = @DiaChi,
                    SoDienThoai = @DienThoai
                WHERE MaNCC = @Ma", conn))
            {
                GanThamSo(cmd, ma, ten, diaChi, dienThoai);
                conn.Open();

                if (cmd.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException(
                        "Không tìm thấy nhà cung ứng cần sửa.");
            }
        }

        public void Xoa(string ma)
        {
            using (SqlConnection conn = DbConnectionFactory.TaoKetNoi())
            using (SqlCommand cmd = new SqlCommand(
                "DELETE FROM dbo.NhaCungUng WHERE MaNCC = @Ma", conn))
            {
                cmd.Parameters.Add("@Ma", SqlDbType.VarChar, 10).Value = ma;
                conn.Open();

                if (cmd.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException(
                        "Không tìm thấy nhà cung ứng cần xóa.");
            }
        }

        private void GanThamSo(
            SqlCommand cmd, string ma, string ten,
            string diaChi, string dienThoai)
        {
            cmd.Parameters.Add("@Ma", SqlDbType.VarChar, 10).Value = ma.Trim();
            cmd.Parameters.Add("@Ten", SqlDbType.NVarChar, 150).Value = ten.Trim();
            cmd.Parameters.Add("@DiaChi", SqlDbType.NVarChar, 250).Value =
                string.IsNullOrWhiteSpace(diaChi) ? (object)DBNull.Value : diaChi.Trim();
            cmd.Parameters.Add("@DienThoai", SqlDbType.VarChar, 20).Value =
                string.IsNullOrWhiteSpace(dienThoai) ? (object)DBNull.Value : dienThoai.Trim();
        }
    }
}
