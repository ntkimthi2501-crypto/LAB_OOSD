﻿
using System;
using System.Configuration;
using System.Data.SqlClient;

namespace QuanLyCuaHangNuocGiaiKhat.Data
{
    public static class DbConnectionFactory
    {
        public static SqlConnection TaoKetNoi()
        {
            ConnectionStringSettings cauHinh =
                ConfigurationManager.ConnectionStrings[
                    "QuanLyCuaHangNuocGiaiKhat"
                ];

            if (cauHinh == null)
            {
                throw new InvalidOperationException(
                    "Khong tim thay chuoi ket noi trong App.config."
                );
            }

            return new SqlConnection(cauHinh.ConnectionString);
        }

        public static bool KiemTraKetNoi(out string thongBao)
        {
            try
            {
                using (SqlConnection ketNoi = TaoKetNoi())
                {
                    ketNoi.Open();

                    using (SqlCommand lenh = new SqlCommand(
                        "SELECT DB_NAME()", ketNoi))
                    {
                        string tenDatabase =
                            Convert.ToString(lenh.ExecuteScalar());

                        thongBao =
                            "Ket noi SQL Server thanh cong!\n" +
                            "Database: " + tenDatabase;

                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                thongBao =
                    "Ket noi that bai!\n\nChi tiet: " + ex.Message;

                return false;
            }
        }
    }
}
