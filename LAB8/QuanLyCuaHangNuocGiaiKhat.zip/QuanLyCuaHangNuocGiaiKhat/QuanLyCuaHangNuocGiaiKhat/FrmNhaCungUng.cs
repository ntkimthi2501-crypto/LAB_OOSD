﻿
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyCuaHangNuocGiaiKhat.Service;

namespace QuanLyCuaHangNuocGiaiKhat
{
    public partial class FrmNhaCungUng : Form
    {
        private readonly NhaCungUngService service =
            new NhaCungUngService();

        private TextBox txtMa;
        private TextBox txtTen;
        private TextBox txtDiaChi;
        private TextBox txtDienThoai;
        private TextBox txtTimKiem;
        private DataGridView dgvNhaCungUng;

        public FrmNhaCungUng()
        {
            InitializeComponent();

            // Tạo giao diện bằng code
            TaoGiaoDien();

            // Tải dữ liệu khi form được mở
            Load += FrmNhaCungUng_Load;
        }

        private void TaoGiaoDien()
        {
            Controls.Clear();

            Text = "Quản lý nhà cung ứng";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1100, 700);
            MinimumSize = new Size(900, 600);
            BackColor = Color.FromArgb(245, 247, 250);
            Font = new Font("Arial", 10);

            // Bố cục chính: tiêu đề, nhập liệu, nút, bảng
            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(0),
                Margin = new Padding(0),
                BackColor = Color.FromArgb(245, 247, 250)
            };

            layout.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 100));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 75));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 155));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 55));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));

            // 1. Tiêu đề
            Label lblTieuDe = new Label
            {
                Text = "QUẢN LÝ NHÀ CUNG ỨNG",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 21, FontStyle.Bold),
                ForeColor = Color.FromArgb(36, 70, 110),
                BackColor = Color.FromArgb(245, 247, 250)
            };

            layout.Controls.Add(lblTieuDe, 0, 0);

            // 2. Khu vực nhập thông tin
            TableLayoutPanel pnlNhap = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 2,
                Padding = new Padding(20, 15, 20, 10),
                BackColor = Color.White,
                Margin = new Padding(0)
            };

            pnlNhap.ColumnStyles.Add(
                new ColumnStyle(SizeType.Absolute, 160));

            pnlNhap.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 40));

            pnlNhap.ColumnStyles.Add(
                new ColumnStyle(SizeType.Absolute, 150));

            pnlNhap.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 60));

            pnlNhap.RowStyles.Add(
                new RowStyle(SizeType.Percent, 50));

            pnlNhap.RowStyles.Add(
                new RowStyle(SizeType.Percent, 50));

            // Mã nhà cung ứng
            Label lblMa = TaoNhan("Mã nhà cung ứng:");
            txtMa = TaoTextBox();

            // Tên nhà cung ứng
            Label lblTen = TaoNhan("Tên nhà cung ứng:");
            txtTen = TaoTextBox();

            // Địa chỉ
            Label lblDiaChi = TaoNhan("Địa chỉ:");
            txtDiaChi = TaoTextBox();

            // Số điện thoại
            Label lblDienThoai = TaoNhan("Số điện thoại:");
            txtDienThoai = TaoTextBox();

            pnlNhap.Controls.Add(lblMa, 0, 0);
            pnlNhap.Controls.Add(txtMa, 1, 0);

            pnlNhap.Controls.Add(lblDiaChi, 2, 0);
            pnlNhap.Controls.Add(txtDiaChi, 3, 0);

            pnlNhap.Controls.Add(lblTen, 0, 1);
            pnlNhap.Controls.Add(txtTen, 1, 1);

            pnlNhap.Controls.Add(lblDienThoai, 2, 1);
            pnlNhap.Controls.Add(txtDienThoai, 3, 1);

            layout.Controls.Add(pnlNhap, 0, 1);

            // 3. Khu vực nút chức năng và tìm kiếm
            FlowLayoutPanel pnlNut = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(15, 8, 10, 5),
                Margin = new Padding(0),
                BackColor = Color.FromArgb(245, 247, 250),
                AutoScroll = true
            };

            ThemNut(
                pnlNut, "Thêm",
                Color.FromArgb(36, 92, 60),
                BtnThem_Click);

            ThemNut(
                pnlNut, "Sửa",
                Color.FromArgb(40, 110, 180),
                BtnSua_Click);

            ThemNut(
                pnlNut, "Xóa",
                Color.FromArgb(190, 55, 55),
                BtnXoa_Click);

            ThemNut(
                pnlNut, "Làm mới",
                Color.Gray,
                BtnLamMoi_Click);

            txtTimKiem = new TextBox
            {
                Width = 220,
                Height = 32,
                Font = new Font("Arial", 10),
                Margin = new Padding(20, 5, 5, 5)
            };

            pnlNut.Controls.Add(txtTimKiem);

            Button btnTim = new Button
            {
                Text = "Tìm kiếm",
                Width = 110,
                Height = 32,
                BackColor = Color.FromArgb(36, 70, 110),
                ForeColor = Color.White,
                Font = new Font("Arial", 10),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(5)
            };

            btnTim.FlatAppearance.BorderSize = 0;
            btnTim.Click += BtnTim_Click;

            pnlNut.Controls.Add(btnTim);

            layout.Controls.Add(pnlNut, 0, 2);

            // 4. Bảng danh sách nhà cung ứng
            dgvNhaCungUng = new DataGridView
            {
                Name = "dgvNhaCungUng",
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                RowHeadersVisible = false,
                AutoGenerateColumns = true,
                Margin = new Padding(15)
            };

            dgvNhaCungUng.CellClick +=
                DgvNhaCungUng_CellClick;

            layout.Controls.Add(dgvNhaCungUng, 0, 3);

            // Thêm bố cục chính vào form
            Controls.Add(layout);
        }

        private Label TaoNhan(string noiDung)
        {
            return new Label
            {
                Text = noiDung,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Arial", 10),
                Margin = new Padding(5)
            };
        }

        private TextBox TaoTextBox()
        {
            return new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Arial", 10),
                Margin = new Padding(5, 8, 12, 8)
            };
        }

        private void ThemNut(
            FlowLayoutPanel panel,
            string noiDung,
            Color mau,
            EventHandler suKien)
        {
            Button btn = new Button
            {
                Text = noiDung,
                Width = 105,
                Height = 32,
                BackColor = mau,
                ForeColor = Color.White,
                Font = new Font("Arial", 10),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(5)
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.Click += suKien;

            panel.Controls.Add(btn);
        }

        // Tải danh sách khi mở form
        private void FrmNhaCungUng_Load(
            object sender, EventArgs e)
        {
            TaiDanhSach();
        }

        // Đọc dữ liệu từ Service
        private void TaiDanhSach(string tuKhoa = "")
        {
            try
            {
                DataTable dt = service.LayDanhSach(tuKhoa);
                dgvNhaCungUng.DataSource = dt;

                if (dgvNhaCungUng.Columns.Contains("MaNCC"))
                    dgvNhaCungUng.Columns["MaNCC"].HeaderText =
                        "Mã nhà cung ứng";

                if (dgvNhaCungUng.Columns.Contains("TenNCC"))
                    dgvNhaCungUng.Columns["TenNCC"].HeaderText =
                        "Tên nhà cung ứng";

                if (dgvNhaCungUng.Columns.Contains("DiaChi"))
                    dgvNhaCungUng.Columns["DiaChi"].HeaderText =
                        "Địa chỉ";

                if (dgvNhaCungUng.Columns.Contains("SoDienThoai"))
                    dgvNhaCungUng.Columns["SoDienThoai"].HeaderText =
                        "Số điện thoại";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không tải được danh sách nhà cung ứng.\n\n"
                    + ex.Message,
                    "Lỗi tải dữ liệu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // Thêm nhà cung ứng
        private void BtnThem_Click(object sender, EventArgs e)
        {
            try
            {
                service.Them(
                    txtMa.Text.Trim(),
                    txtTen.Text.Trim(),
                    txtDiaChi.Text.Trim(),
                    txtDienThoai.Text.Trim());

                MessageBox.Show("Thêm nhà cung ứng thành công!");

                TaiDanhSach();
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Không thể thêm nhà cung ứng",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // Sửa nhà cung ứng
        private void BtnSua_Click(object sender, EventArgs e)
        {
            try
            {
                service.CapNhat(
                    txtMa.Text.Trim(),
                    txtTen.Text.Trim(),
                    txtDiaChi.Text.Trim(),
                    txtDienThoai.Text.Trim());

                MessageBox.Show("Cập nhật nhà cung ứng thành công!");

                TaiDanhSach();
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Không thể cập nhật nhà cung ứng",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // Xóa nhà cung ứng
        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMa.Text))
            {
                MessageBox.Show(
                    "Bà hãy chọn nhà cung ứng cần xóa trước nha!");
                return;
            }

            DialogResult xacNhan = MessageBox.Show(
                "Bà có chắc chắn muốn xóa nhà cung ứng này không?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (xacNhan != DialogResult.Yes)
                return;

            try
            {
                service.Xoa(txtMa.Text.Trim());

                MessageBox.Show("Xóa nhà cung ứng thành công!");

                TaiDanhSach();
                XoaTrang();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể xóa nhà cung ứng. Có thể nhà cung ứng "
                    + "đang được sử dụng trong dữ liệu khác.\n\n"
                    + ex.Message,
                    "Lỗi xóa",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // Làm mới dữ liệu
        private void BtnLamMoi_Click(object sender, EventArgs e)
        {
            XoaTrang();
            TaiDanhSach();
        }

        // Tìm kiếm nhà cung ứng
        private void BtnTim_Click(object sender, EventArgs e)
        {
            TaiDanhSach(txtTimKiem.Text.Trim());
        }

        // Chọn một dòng để đưa thông tin lên ô nhập
        private void DgvNhaCungUng_CellClick(
            object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row =
                dgvNhaCungUng.Rows[e.RowIndex];

            txtMa.Text = LayGiaTri(row, "MaNCC");
            txtTen.Text = LayGiaTri(row, "TenNCC");
            txtDiaChi.Text = LayGiaTri(row, "DiaChi");
            txtDienThoai.Text = LayGiaTri(row, "SoDienThoai");
        }

        private string LayGiaTri(
            DataGridViewRow row,
            string tenCot)
        {
            if (!dgvNhaCungUng.Columns.Contains(tenCot))
                return "";

            object giaTri = row.Cells[tenCot].Value;

            if (giaTri == null || giaTri == DBNull.Value)
                return "";

            return giaTri.ToString();
        }

        // Xóa thông tin đang nhập
        private void XoaTrang()
        {
            txtMa.Clear();
            txtTen.Clear();
            txtDiaChi.Clear();
            txtDienThoai.Clear();
            txtTimKiem.Clear();
            txtMa.Focus();
        }
    }
}
