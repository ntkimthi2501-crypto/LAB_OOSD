﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyBenhAn.Modules_HoSo
{
    public partial class FrmTraCuuHoSo : Form
    {
        private TextBox txtSoHoSo;
        private TextBox txtHoTen;
        private TextBox txtDienThoai;
        private Button btnTraCuu;

        private DataGridView dgvHoSo;
        private DataGridView dgvPhieuKham;
        private DataGridView dgvXetNghiem;
        private DataGridView dgvToaThuoc;

        public FrmTraCuuHoSo()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            Text = "Tra cứu hồ sơ bệnh án";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1150, 750);
            MinimumSize = new Size(900, 600);
            BackColor = Color.White;

            // Tiêu đề
            Label lblTieuDe = new Label
            {
                Text = "TRA CỨU HỒ SƠ BỆNH ÁN",
                Font = new Font("Segoe UI", 17, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Location = new Point(20, 15),
                AutoSize = true
            };

            // Ô tìm kiếm số hồ sơ
            Label lblSoHoSo = new Label
            {
                Text = "Số hồ sơ:",
                Location = new Point(25, 65),
                AutoSize = true
            };

            txtSoHoSo = new TextBox
            {
                Location = new Point(105, 60),
                Width = 180
            };

            // Ô tìm kiếm họ tên
            Label lblHoTen = new Label
            {
                Text = "Họ tên:",
                Location = new Point(310, 65),
                AutoSize = true
            };

            txtHoTen = new TextBox
            {
                Location = new Point(370, 60),
                Width = 180
            };

            // Ô tìm kiếm điện thoại
            Label lblDienThoai = new Label
            {
                Text = "Điện thoại:",
                Location = new Point(570, 65),
                AutoSize = true
            };

            txtDienThoai = new TextBox
            {
                Location = new Point(650, 60),
                Width = 160
            };

            // Nút tra cứu
            btnTraCuu = new Button
            {
                Text = "Tra cứu",
                Location = new Point(835, 57),
                Size = new Size(110, 32),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            btnTraCuu.Click += BtnTraCuu_Click;

            // Bảng thông tin hồ sơ
            Label lblHoSo = TaoNhan(
                "THÔNG TIN HỒ SƠ", 25, 105);

            dgvHoSo = TaoBang(25, 135, 1080, 100);

            // Bảng phiếu khám
            Label lblPhieuKham = TaoNhan(
                "LỊCH SỬ PHIẾU KHÁM", 25, 245);

            dgvPhieuKham = TaoBang(25, 275, 1080, 120);

            // Bảng xét nghiệm
            Label lblXetNghiem = TaoNhan(
                "LỊCH SỬ XÉT NGHIỆM", 25, 405);

            dgvXetNghiem = TaoBang(25, 435, 1080, 100);

            // Bảng toa thuốc
            Label lblToaThuoc = TaoNhan(
                "LỊCH SỬ TOA THUỐC", 25, 545);

            dgvToaThuoc = TaoBang(25, 575, 1080, 100);

            Controls.Add(lblTieuDe);
            Controls.Add(lblSoHoSo);
            Controls.Add(txtSoHoSo);
            Controls.Add(lblHoTen);
            Controls.Add(txtHoTen);
            Controls.Add(lblDienThoai);
            Controls.Add(txtDienThoai);
            Controls.Add(btnTraCuu);
            Controls.Add(lblHoSo);
            Controls.Add(dgvHoSo);
            Controls.Add(lblPhieuKham);
            Controls.Add(dgvPhieuKham);
            Controls.Add(lblXetNghiem);
            Controls.Add(dgvXetNghiem);
            Controls.Add(lblToaThuoc);
            Controls.Add(dgvToaThuoc);
        }

        private Label TaoNhan(string noiDung, int x, int y)
        {
            return new Label
            {
                Text = noiDung,
                Location = new Point(x, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
        }

        private DataGridView TaoBang(
            int x, int y, int rong, int cao)
        {
            return new DataGridView
            {
                Location = new Point(x, y),
                Size = new Size(rong, cao),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoGenerateColumns = true,
                AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.DisplayedCells,
                ScrollBars = ScrollBars.Both,
                RowHeadersVisible = false
            };
        }

        private void BtnTraCuu_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSoHoSo.Text)
                && string.IsNullOrWhiteSpace(txtHoTen.Text)
                && string.IsNullOrWhiteSpace(txtDienThoai.Text))
            {
                MessageBox.Show(
                    "Vui lòng nhập số hồ sơ, họ tên hoặc số điện thoại.");
                return;
            }

            try
            {
                using (SqlConnection conn =
                    new SqlConnection(Db.ConnStr))
                {
                    conn.Open();

                    // 1. Tra cứu hồ sơ
                    using (SqlCommand cmd = new SqlCommand(
                        "dbo.sp_TraCuuHoSo", conn))
                    {
                        cmd.CommandType =
                            CommandType.StoredProcedure;

                        cmd.Parameters.Add(
                            "@soHoSo", SqlDbType.VarChar, 10)
                            .Value = GiaTriHoacNull(txtSoHoSo.Text);

                        cmd.Parameters.Add(
                            "@hoTen", SqlDbType.NVarChar, 100)
                            .Value = GiaTriHoacNull(txtHoTen.Text);

                        cmd.Parameters.Add(
                            "@dienThoai", SqlDbType.VarChar, 15)
                            .Value = GiaTriHoacNull(txtDienThoai.Text);

                        DataTable dtHoSo = new DataTable();

                        using (SqlDataAdapter adapter =
                            new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dtHoSo);
                        }

                        dgvHoSo.DataSource = dtHoSo;

                        if (dtHoSo.Rows.Count == 0)
                        {
                            dgvPhieuKham.DataSource = null;
                            dgvXetNghiem.DataSource = null;
                            dgvToaThuoc.DataSource = null;

                            MessageBox.Show(
                                "Không tìm thấy hồ sơ phù hợp.");
                            return;
                        }

                        // Lấy mã hồ sơ để tìm lịch sử khám
                        if (!dtHoSo.Columns.Contains("maHoSo"))
                        {
                            MessageBox.Show(
                                "Kết quả SQL không có cột maHoSo. " +
                                "Cần đối chiếu lại thủ tục sp_TraCuuHoSo.");
                            return;
                        }

                        int maHoSo = Convert.ToInt32(
                            dtHoSo.Rows[0]["maHoSo"]);

                        // 2. Lấy lịch sử khám, xét nghiệm và toa thuốc
                        using (SqlCommand cmdLS = new SqlCommand(
                            "dbo.sp_LichSuKham", conn))
                        {
                            cmdLS.CommandType =
                                CommandType.StoredProcedure;

                            cmdLS.Parameters.Add(
                                "@maHoSo", SqlDbType.Int).Value = maHoSo;

                            DataSet ds = new DataSet();

                            using (SqlDataAdapter adapter =
                                new SqlDataAdapter(cmdLS))
                            {
                                adapter.Fill(ds);
                            }

                            dgvPhieuKham.DataSource =
                                ds.Tables.Count > 0
                                    ? ds.Tables[0] : null;

                            dgvXetNghiem.DataSource =
                                ds.Tables.Count > 1
                                    ? ds.Tables[1] : null;

                            dgvToaThuoc.DataSource =
                                ds.Tables.Count > 2
                                    ? ds.Tables[2] : null;
                        }

                        MessageBox.Show(
                            "Đã thực hiện tra cứu hồ sơ.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Tra cứu thất bại:\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private object GiaTriHoacNull(string giaTri)
        {
            if (string.IsNullOrWhiteSpace(giaTri))
                return DBNull.Value;

            return giaTri.Trim();
        }
    }
}
