﻿
using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyBenhAn
{
    public static class Db
    {
        // Chuoi ket noi SQL Server
        public static string ConnStr =
            @"Server=localhost;Database=QuanLyBenhAn;Trusted_Connection=True;";

        // Tao tham so SQL
        public static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        // Tham so du lieu hinh anh
        public static SqlParameter PBinary(string name, byte[] value)
        {
            SqlParameter p = new SqlParameter(
                name, SqlDbType.VarBinary, -1);

            p.Value = (object)value ?? DBNull.Value;

            return p;
        }

        // Tham so OUTPUT
        public static SqlParameter POut(string name, SqlDbType type)
        {
            SqlParameter p = new SqlParameter(name, type);
            p.Direction = ParameterDirection.Output;

            return p;
        }

        // Goi Stored Procedure de lay du lieu
        public static DataTable Query(
            string proc, params SqlParameter[] ps)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(proc, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                if (ps != null && ps.Length > 0)
                    cmd.Parameters.AddRange(ps);

                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        // Goi Stored Procedure de them hoac cap nhat du lieu
        public static void Exec(
            string proc, params SqlParameter[] ps)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(proc, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                if (ps != null && ps.Length > 0)
                    cmd.Parameters.AddRange(ps);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // Kiem tra ket noi database
        public static bool TestConnection(out string message)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    conn.Open();

                    string sql =
                        "SELECT @@SERVERNAME, DB_NAME(), " +
                        "(SELECT COUNT(*) FROM BenhNhan)";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            message =
                                "KET NOI THANH CONG!\n\n" +
                                "Server: " + reader.GetString(0) + "\n" +
                                "Database: " + reader.GetString(1) + "\n" +
                                "So benh nhan hien co: " +
                                reader.GetInt32(2);

                            return true;
                        }
                    }
                }

                message = "Khong doc duoc thong tin database.";
                return false;
            }
            catch (Exception ex)
            {
                message = "KET NOI THAT BAI!\n\n" + ex.Message;
                return false;
            }
        }
    }
}
