﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyBenhAn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            // Cấu hình cửa sổ chính
            this.Text = "HỆ THỐNG QUẢN LÝ BỆNH ÁN";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(900, 600);
            this.MinimumSize = new Size(800, 500);
            this.BackColor = Color.FromArgb(240, 245, 250);

            // Xóa các điều khiển cũ trên Form nếu có
            this.Controls.Clear();

            // Tiêu đề
            Label lblTieuDe = new Label
            {
                Text = "HỆ THỐNG QUẢN LÝ BỆNH ÁN",
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                ForeColor = Color.FromArgb(25, 75, 125),
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 90
            };

            // Dòng mô tả
            Label lblMoTa = new Label
            {
                Text = "QUẢN LÝ BỆNH NHÂN - HỒ SƠ - LỊCH KHÁM - VIỆN PHÍ",
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.DimGray,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 40
            };

            // Khu vực chứa các nút chức năng
            FlowLayoutPanel pnlMenu = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(50, 35, 50, 30),
                AutoScroll = true,
                WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight
            };

            // Nút 1: Bệnh nhân
            TaoNutMenu(pnlMenu, "BỆNH NHÂN", () =>
            {
                using (QuanLyBenhAn.Modules_BenhNhan.FrmBenhNhan frm =
                    new QuanLyBenhAn.Modules_BenhNhan.FrmBenhNhan())
                {
                    frm.ShowDialog();
                }
            });

            // Nút 2: Tra cứu hồ sơ
            TaoNutMenu(pnlMenu, "TRA CỨU HỒ SƠ", () =>
            {
                using (QuanLyBenhAn.Modules_HoSo.FrmTraCuuHoSo frm =
                    new QuanLyBenhAn.Modules_HoSo.FrmTraCuuHoSo())
                {
                    frm.ShowDialog();
                }
            });

            // Nút 3: Lịch khám định kỳ
            TaoNutMenu(pnlMenu, "LỊCH KHÁM ĐỊNH KỲ", () =>
            {
                MessageBox.Show(
                    "Chức năng lịch khám định kỳ sẽ được xây dựng ở bước tiếp theo.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            });

            // Nút 4: Khám bệnh
            TaoNutMenu(pnlMenu, "KHÁM BỆNH", () =>
            {
                MessageBox.Show(
                    "Chức năng khám bệnh, xét nghiệm và toa thuốc sẽ được xây dựng ở bước tiếp theo.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            });

            // Nút 5: Thanh toán viện phí
            TaoNutMenu(pnlMenu, "THANH TOÁN VIỆN PHÍ", () =>
            {
                MessageBox.Show(
                    "Chức năng thanh toán viện phí sẽ được xây dựng ở bước tiếp theo.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            });

            // Nút 6: Kiểm thử hệ thống
            TaoNutMenu(pnlMenu, "KIỂM THỬ HỆ THỐNG", () =>
            {
                MessageBox.Show(
                    "Hệ thống tập trung kiểm thử 4 nhóm quy tắc:\n\n" +
                    "1. Đăng ký lần đầu, lệ phí năm và cấp hồ sơ.\n" +
                    "2. Tra cứu hồ sơ và lịch sử khám.\n" +
                    "3. Lịch khám định kỳ theo quý.\n" +
                    "4. Liên kết xét nghiệm, toa thuốc và hoàn tất sau thanh toán.",
                    "Các quy tắc kiểm thử",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            });

            // Thêm điều khiển theo thứ tự
            this.Controls.Add(pnlMenu);
            this.Controls.Add(lblMoTa);
            this.Controls.Add(lblTieuDe);
        }

        private void TaoNutMenu(
            FlowLayoutPanel panel,
            string noiDung,
            Action xuLy)
        {
            Button btn = new Button
            {
                Text = noiDung,
                Size = new Size(340, 85),
                Margin = new Padding(15),
                BackColor = Color.FromArgb(35, 105, 165),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (sender, e) => xuLy();

            panel.Controls.Add(btn);
        }
    }
}
