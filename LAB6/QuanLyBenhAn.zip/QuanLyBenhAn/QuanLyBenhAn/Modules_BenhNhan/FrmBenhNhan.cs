﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace QuanLyBenhAn.Modules_BenhNhan
{
    public partial class FrmBenhNhan : Form
    {
        private TextBox txtHoTen;
        private TextBox txtDiaChi;
        private TextBox txtNgaySinh;
        private TextBox txtDienThoai;
        private TextBox txtMaNV;
        private TextBox txtLePhi;
        private TextBox txtTimKiem;
        private DataGridView dgvBenhNhan;

        public FrmBenhNhan()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            Text = "Quản lý bệnh nhân";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1100, 720);
            MinimumSize = new Size(900, 650);
            BackColor = Color.WhiteSmoke;

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "QUẢN LÝ BỆNH NHÂN";
            lblTieuDe.Font = new Font("Segoe UI", 20, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.FromArgb(35, 55, 80);
            lblTieuDe.Location = new Point(25, 20);
            lblTieuDe.AutoSize = true;
            Controls.Add(lblTieuDe);

            TaoNhan("Họ tên:", 30, 85);
            txtHoTen = TaoTextBox(160, 80, 280);

            TaoNhan("Ngày sinh (dd/MM/yyyy):", 30, 130);
            txtNgaySinh = TaoTextBox(220, 125, 220);

            TaoNhan("Địa chỉ:", 30, 175);
            txtDiaChi = TaoTextBox(160, 170, 280);

            TaoNhan("Số điện thoại:", 30, 220);
            txtDienThoai = TaoTextBox(160, 215, 280);

            TaoNhan("Mã nhân viên:", 500, 85);
            txtMaNV = TaoTextBox(620, 80, 180);
            txtMaNV.Text = "1";

            TaoNhan("Lệ phí năm (đồng):", 500, 130);
            txtLePhi = TaoTextBox(620, 125, 180);
            txtLePhi.Text = "200000";

            Label lblGhiChu = new Label();
            lblGhiChu.Text =
                "Ảnh 3x4: chưa chọn (không bắt buộc)";
            lblGhiChu.Location = new Point(500, 175);
            lblGhiChu.AutoSize = true;
            lblGhiChu.ForeColor = Color.DimGray;
            Controls.Add(lblGhiChu);

            Button btnDangKy = TaoNut(
                "Đăng ký lần đầu", 160, 270,
                Color.FromArgb(35, 120, 85));
            btnDangKy.Click += BtnDangKy_Click;

            Button btnLamMoi = TaoNut(
                "Làm mới", 330, 270,
                Color.FromArgb(90, 100, 115));
            btnLamMoi.Click += delegate { XoaForm(); };

            Label lblTimKiem = new Label();
            lblTimKiem.Text = "Tìm theo họ tên:";
            lblTimKiem.Location = new Point(30, 335);
            lblTimKiem.AutoSize = true;
            Controls.Add(lblTimKiem);

            txtTimKiem = TaoTextBox(160, 330, 280);

            Button btnTimKiem = TaoNut(
                "Tìm kiếm", 455, 327,
                Color.FromArgb(40, 100, 160));
            btnTimKiem.Click += delegate { TaiDanhSach(); };

            Button btnTaiLai = TaoNut(
                "Tải lại danh sách", 565, 327,
                Color.FromArgb(90, 100, 115));
            btnTaiLai.Click += delegate
            {
                txtTimKiem.Clear();
                TaiDanhSach();
            };

            dgvBenhNhan = new DataGridView();
            dgvBenhNhan.Location = new Point(30, 380);
            dgvBenhNhan.Size = new Size(1010, 260);
            dgvBenhNhan.Anchor =
                AnchorStyles.Top | AnchorStyles.Bottom |
                AnchorStyles.Left | AnchorStyles.Right;
            dgvBenhNhan.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            dgvBenhNhan.ReadOnly = true;
            dgvBenhNhan.AllowUserToAddRows = false;
            dgvBenhNhan.AllowUserToDeleteRows = false;
            dgvBenhNhan.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvBenhNhan.MultiSelect = false;
            dgvBenhNhan.BackgroundColor = Color.White;
            dgvBenhNhan.RowHeadersVisible = false;
            Controls.Add(dgvBenhNhan);

            Shown += delegate { TaiDanhSach(); };
        }

        private void TaoNhan(string noiDung, int x, int y)
        {
            Label lbl = new Label();
            lbl.Text = noiDung;
            lbl.Location = new Point(x, y + 5);
            lbl.AutoSize = true;
            lbl.Font = new Font("Segoe UI", 9);
            Controls.Add(lbl);
        }

        private TextBox TaoTextBox(int x, int y, int width)
        {
            TextBox txt = new TextBox();
            txt.Location = new Point(x, y);
            txt.Size = new Size(width, 28);
            txt.Font = new Font("Segoe UI", 10);
            Controls.Add(txt);
            return txt;
        }

        private Button TaoNut(
            string noiDung, int x, int y, Color mauNen)
        {
            Button btn = new Button();
            btn.Text = noiDung;
            btn.Location = new Point(x, y);
            btn.Size = new Size(155, 36);
            btn.BackColor = mauNen;
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            btn.Cursor = Cursors.Hand;
            Controls.Add(btn);
            return btn;
        }

        private void BtnDangKy_Click(object sender, EventArgs e)
        {
            string hoTen = txtHoTen.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();
            string dienThoai = txtDienThoai.Text.Trim();

            DateTime ngaySinh;
            int maNV;
            decimal soTienLePhi;

            if (hoTen.Length == 0)
            {
                MessageBox.Show("Vui lòng nhập họ tên bệnh nhân.");
                txtHoTen.Focus();
                return;
            }

            if (!DateTime.TryParseExact(
                txtNgaySinh.Text.Trim(),
                "dd/MM/yyyy",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out ngaySinh))
            {
                MessageBox.Show(
                    "Ngày sinh không hợp lệ. Ví dụ: 15/08/2002.");
                txtNgaySinh.Focus();
                return;
            }

            if (ngaySinh.Date >= DateTime.Today)
            {
                MessageBox.Show("Ngày sinh phải trước ngày hôm nay.");
                return;
            }

            if (string.IsNullOrWhiteSpace(diaChi))
            {
                MessageBox.Show("Vui lòng nhập địa chỉ.");
                txtDiaChi.Focus();
                return;
            }

            if (dienThoai.Length == 0)
            {
                MessageBox.Show("Vui lòng nhập số điện thoại.");
                txtDienThoai.Focus();
                return;
            }

            if (dienThoai.Length > 15)
            {
                MessageBox.Show("Số điện thoại không được quá 15 ký tự.");
                return;
            }

            if (!int.TryParse(txtMaNV.Text.Trim(), out maNV) ||
                maNV <= 0)
            {
                MessageBox.Show("Mã nhân viên phải là số nguyên dương.");
                txtMaNV.Focus();
                return;
            }

            if (!decimal.TryParse(
                txtLePhi.Text.Trim(),
                NumberStyles.Number,
                CultureInfo.InvariantCulture,
                out soTienLePhi) || soTienLePhi <= 0)
            {
                MessageBox.Show("Lệ phí năm phải lớn hơn 0.");
                txtLePhi.Focus();
                return;
            }

            try
            {
                int maBN;
                int maHoSo;

                using (SqlConnection conn =
                    new SqlConnection(Db.ConnStr))
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.sp_DangKyBenhNhanLanDau", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(
                        "@hoTen", SqlDbType.NVarChar, 100).Value =
                        hoTen;

                    cmd.Parameters.Add(
                        "@diaChi", SqlDbType.NVarChar, 200).Value =
                        diaChi;

                    cmd.Parameters.Add(
                        "@ngaySinh", SqlDbType.Date).Value =
                        ngaySinh.Date;

                    cmd.Parameters.Add(
                        "@dienThoai", SqlDbType.VarChar, 15).Value =
                        dienThoai;

                    SqlParameter anhParam = cmd.Parameters.Add(
                        "@anh3x4", SqlDbType.VarBinary, -1);
                    anhParam.Value = DBNull.Value;

                    cmd.Parameters.Add(
                        "@maNV", SqlDbType.Int).Value = maNV;

                    SqlParameter phiParam = cmd.Parameters.Add(
                        "@soTienLePhi", SqlDbType.Decimal);
                    phiParam.Precision = 18;
                    phiParam.Scale = 0;
                    phiParam.Value = soTienLePhi;

                    SqlParameter bnParam = cmd.Parameters.Add(
                        "@maBN", SqlDbType.Int);
                    bnParam.Direction = ParameterDirection.Output;

                    SqlParameter hoSoParam = cmd.Parameters.Add(
                        "@maHoSo", SqlDbType.Int);
                    hoSoParam.Direction = ParameterDirection.Output;

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    maBN = Convert.ToInt32(bnParam.Value);
                    maHoSo = Convert.ToInt32(hoSoParam.Value);
                }

                MessageBox.Show(
                    "Đăng ký bệnh nhân thành công!\n\n" +
                    "Mã bệnh nhân: " + maBN + "\n" +
                    "Mã hồ sơ bệnh án: " + maHoSo + "\n" +
                    "Lệ phí năm: " +
                    soTienLePhi.ToString("N0") + " đồng",
                    "Đăng ký thành công",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                XoaForm();
                TaiDanhSach();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Đăng ký bệnh nhân thất bại.\n\n" +
                    "Chi tiết lỗi: " + ex.Message,
                    "Lỗi đăng ký",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void TaiDanhSach()
        {
            try
            {
                using (SqlConnection conn =
                    new SqlConnection(Db.ConnStr))
                using (SqlCommand cmd = new SqlCommand(
                    "SELECT * FROM dbo.BenhNhan ORDER BY maBN DESC",
                    conn))
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    string tuKhoa = txtTimKiem.Text.Trim();

                    if (tuKhoa.Length > 0 &&
                        dt.Columns.Contains("hoTen"))
                    {
                        DataView dv = dt.DefaultView;
                        dv.RowFilter =
                            "hoTen LIKE '%" +
                            tuKhoa.Replace("'", "''") + "%'";

                        dgvBenhNhan.DataSource = dv;
                    }
                    else
                    {
                        dgvBenhNhan.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không tải được danh sách bệnh nhân.\n\n" +
                    "Chi tiết lỗi: " + ex.Message,
                    "Lỗi tải dữ liệu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void XoaForm()
        {
            txtHoTen.Clear();
            txtDiaChi.Clear();
            txtNgaySinh.Clear();
            txtDienThoai.Clear();
            txtTimKiem.Clear();

            txtMaNV.Text = "1";
            txtLePhi.Text = "200000";

            txtHoTen.Focus();
        }
    }
}
