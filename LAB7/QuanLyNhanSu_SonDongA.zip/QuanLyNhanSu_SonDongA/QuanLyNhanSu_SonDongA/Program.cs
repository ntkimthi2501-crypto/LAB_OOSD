﻿
using System;
using System.Windows.Forms;
using QuanLyNhanSu_SonDongA.Forms;

namespace QuanLyNhanSu_SonDongA
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new FrmMain());
        }
    }
}
