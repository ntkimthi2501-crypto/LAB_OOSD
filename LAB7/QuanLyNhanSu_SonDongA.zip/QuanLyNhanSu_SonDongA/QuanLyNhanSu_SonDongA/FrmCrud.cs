﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using QuanLyNhanSu_SonDongA.Data;
using QuanLyNhanSu_SonDongA.Services;

namespace QuanLyNhanSu_SonDongA
{
    public class FrmCrud : Form
    {
        private readonly string tenBang;
        private readonly CrudService service = new CrudService();

        private DataGridView dgvDuLieu;
        private FlowLayoutPanel pnlNhapLieu;
        private TextBox txtTimKiem;
        private Label lblTrangThai;

        private readonly Dictionary<string, TextBox> cacONhap =
            new Dictionary<string, TextBox>(
                StringComparer.OrdinalIgnoreCase);

        private readonly List<CotThongTin> danhSachCot =
            new List<CotThongTin>();

        private string cotKhoaChinh;
        private object giaTriKhoaDangChon;

        private static readonly string[] CacBangHopLe =
        {
            "PhongBan",
            "NhanVien",
            "QuyetDinhTuyenDung",
            "HopDongLaoDong",
            "QuyetDinhChucVu",
            "QuyetDinhLuong",
            "ChamCong",
            "PhieuPhuTroi",
            "BangLuong",
            "QuyetDinhKhenThuong",
            "PhieuChiKhenThuong",
            "QuyetDinhKyLuat",
            "PhieuThuPhat",
            "BaoHiem"
        };

        private class CotThongTin
        {
            public string TenCot;
            public string KieuDuLieu;
            public bool ChoPhepNull;
            public bool TuTang;
            public bool CotTinh;
        }

        public FrmCrud(string bang)
        {
            if (string.IsNullOrWhiteSpace(bang) ||
                !CacBangHopLe.Contains(
                    bang, StringComparer.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Tên bảng không hợp lệ.");
            }

            tenBang = CacBangHopLe.First(
                x => x.Equals(
                    bang, StringComparison.OrdinalIgnoreCase));

            KhoiTaoGiaoDien();
            DocCauTrucBang();
            TaoONhapLieu();
            TaiDuLieu();
        }

        private void KhoiTaoGiaoDien()
        {
            Text = "Quản lý dữ liệu - " + tenBang;
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(1000, 650);
            Font = new Font("Segoe UI", 9F);
            BackColor = Color.FromArgb(245, 247, 250);

            TableLayoutPanel pnlChinh = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(12)
            };

            pnlChinh.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 48));
            pnlChinh.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 48));
            pnlChinh.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));
            pnlChinh.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 30));

            Label lblTieuDe = new Label
            {
                Text = "QUẢN LÝ DỮ LIỆU: " +
                    tenBang.ToUpperInvariant(),
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(31, 78, 121),
                TextAlign = ContentAlignment.MiddleLeft
            };

            FlowLayoutPanel pnlTimKiem = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 5, 0, 0)
            };

            txtTimKiem = new TextBox
            {
                Width = 300,
                Height = 30,
                Font = new Font("Segoe UI", 10F)
            };

            Button btnTimKiem =
                TaoNut("Tìm kiếm", Color.FromArgb(52, 120, 190));

            Button btnLamMoi =
                TaoNut("Làm mới", Color.FromArgb(90, 100, 110));

            btnTimKiem.Click += (s, e) => TimKiemDuLieu();

            btnLamMoi.Click += (s, e) =>
            {
                txtTimKiem.Clear();
                TaiDuLieu();
                XoaTrangNhapLieu();
            };

            txtTimKiem.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    TimKiemDuLieu();
                    e.SuppressKeyPress = true;
                }
            };

            pnlTimKiem.Controls.Add(new Label
            {
                Text = "Từ khóa:",
                AutoSize = true,
                Margin = new Padding(0, 7, 8, 0)
            });
            pnlTimKiem.Controls.Add(txtTimKiem);
            pnlTimKiem.Controls.Add(btnTimKiem);
            pnlTimKiem.Controls.Add(btnLamMoi);

            SplitContainer pnlNoiDung = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 720,
                Panel1MinSize = 400,
                Panel2MinSize = 300,
                BackColor = Color.White
            };

            dgvDuLieu = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.DisplayedCells,
                SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                RowHeadersVisible = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                AutoGenerateColumns = true
            };

            dgvDuLieu.SelectionChanged +=
                (s, e) => ChonDongDuLieu();

            TableLayoutPanel pnlBenPhai = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(10)
            };

            pnlBenPhai.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 36));
            pnlBenPhai.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));
            pnlBenPhai.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 100));

            pnlBenPhai.Controls.Add(new Label
            {
                Text = "THÔNG TIN BẢN GHI",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(31, 78, 121),
                TextAlign = ContentAlignment.MiddleLeft
            }, 0, 0);

            pnlNhapLieu = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                Padding = new Padding(3)
            };

            pnlBenPhai.Controls.Add(pnlNhapLieu, 0, 1);

            FlowLayoutPanel pnlNut = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                Padding = new Padding(0, 5, 0, 0)
            };

            Button btnThem =
                TaoNut("Thêm", Color.FromArgb(40, 145, 85));

            Button btnSua =
                TaoNut("Sửa", Color.FromArgb(230, 155, 40));

            Button btnXoa =
                TaoNut("Xóa", Color.FromArgb(200, 65, 65));

            Button btnBoChon =
                TaoNut("Bỏ chọn", Color.FromArgb(90, 100, 110));

            btnThem.Click += (s, e) => ThemDuLieu();
            btnSua.Click += (s, e) => SuaDuLieu();
            btnXoa.Click += (s, e) => XoaDuLieu();
            btnBoChon.Click += (s, e) => XoaTrangNhapLieu();

            pnlNut.Controls.Add(btnThem);
            pnlNut.Controls.Add(btnSua);
            pnlNut.Controls.Add(btnXoa);
            pnlNut.Controls.Add(btnBoChon);

            pnlBenPhai.Controls.Add(pnlNut, 0, 2);

            pnlNoiDung.Panel1.Controls.Add(dgvDuLieu);
            pnlNoiDung.Panel2.Controls.Add(pnlBenPhai);

            lblTrangThai = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Color.DimGray
            };

            pnlChinh.Controls.Add(lblTieuDe, 0, 0);
            pnlChinh.Controls.Add(pnlTimKiem, 0, 1);
            pnlChinh.Controls.Add(pnlNoiDung, 0, 2);
            pnlChinh.Controls.Add(lblTrangThai, 0, 3);

            Controls.Add(pnlChinh);
        }

        private Button TaoNut(string noiDung, Color mau)
        {
            return new Button
            {
                Text = noiDung,
                Width = 95,
                Height = 32,
                BackColor = mau,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font(
                    "Segoe UI", 9F, FontStyle.Bold),
                Margin = new Padding(4, 0, 4, 0),
                Cursor = Cursors.Hand
            };
        }

        private void DocCauTrucBang()
        {
            danhSachCot.Clear();

            using (SqlConnection conn =
                DbConnection.GetConnection())
            {
                conn.Open();

                string sqlCot = @"
SELECT
    c.name AS TenCot,
    ty.name AS KieuDuLieu,
    c.is_nullable,
    c.is_identity,
    c.is_computed
FROM sys.columns c
INNER JOIN sys.tables tb
    ON c.object_id = tb.object_id
INNER JOIN sys.schemas sc
    ON tb.schema_id = sc.schema_id
INNER JOIN sys.types ty
    ON c.user_type_id = ty.user_type_id
WHERE sc.name = 'dbo'
  AND tb.name = @TenBang
ORDER BY c.column_id;";

                using (SqlCommand cmd =
                    new SqlCommand(sqlCot, conn))
                {
                    cmd.Parameters.Add(
                        "@TenBang", SqlDbType.NVarChar, 128)
                        .Value = tenBang;

                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            danhSachCot.Add(new CotThongTin
                            {
                                TenCot = rd["TenCot"].ToString(),
                                KieuDuLieu =
                                    rd["KieuDuLieu"].ToString(),
                                ChoPhepNull =
                                    Convert.ToBoolean(
                                        rd["is_nullable"]),
                                TuTang =
                                    Convert.ToBoolean(
                                        rd["is_identity"]),
                                CotTinh =
                                    Convert.ToBoolean(
                                        rd["is_computed"])
                            });
                        }
                    }
                }

                string sqlKhoa = @"
SELECT c.name
FROM sys.indexes i
INNER JOIN sys.index_columns ic
    ON i.object_id = ic.object_id
   AND i.index_id = ic.index_id
INNER JOIN sys.columns c
    ON ic.object_id = c.object_id
   AND ic.column_id = c.column_id
INNER JOIN sys.tables tb
    ON i.object_id = tb.object_id
INNER JOIN sys.schemas sc
    ON tb.schema_id = sc.schema_id
WHERE sc.name = 'dbo'
  AND tb.name = @TenBang
  AND i.is_primary_key = 1
ORDER BY ic.key_ordinal;";

                using (SqlCommand cmd =
                    new SqlCommand(sqlKhoa, conn))
                {
                    cmd.Parameters.Add(
                        "@TenBang", SqlDbType.NVarChar, 128)
                        .Value = tenBang;

                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        List<string> cacKhoa = new List<string>();

                        while (rd.Read())
                            cacKhoa.Add(rd.GetString(0));

                        if (cacKhoa.Count != 1)
                        {
                            throw new InvalidOperationException(
                                "Bảng " + tenBang +
                                " phải có đúng một cột khóa chính " +
                                "để dùng form CRUD này.");
                        }

                        cotKhoaChinh = cacKhoa[0];
                    }
                }
            }

            if (danhSachCot.Count == 0)
            {
                throw new InvalidOperationException(
                    "Không tìm thấy cấu trúc bảng " +
                    tenBang + ".");
            }
        }

        private void TaoONhapLieu()
        {
            pnlNhapLieu.Controls.Clear();
            cacONhap.Clear();

            foreach (CotThongTin cot in danhSachCot)
            {
                if (cot.TuTang || cot.CotTinh ||
                    cot.KieuDuLieu.Equals(
                        "timestamp",
                        StringComparison.OrdinalIgnoreCase) ||
                    cot.KieuDuLieu.Equals(
                        "rowversion",
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                Panel pnlCot = new Panel
                {
                    Width = 290,
                    Height = 59,
                    Margin = new Padding(0, 0, 0, 5)
                };

                Label lbl = new Label
                {
                    Text = cot.TenCot +
                        (cot.ChoPhepNull ? "" : " *"),
                    Left = 0,
                    Top = 0,
                    Width = 280,
                    Height = 22,
                    Font = new Font(
                        "Segoe UI", 9F, FontStyle.Bold)
                };

                TextBox txt = new TextBox
                {
                    Left = 0,
                    Top = 23,
                    Width = 275,
                    Height = 28,
                    Font = new Font("Segoe UI", 9F),
                    Tag = cot
                };

                if (cot.TenCot.Equals(
                    cotKhoaChinh,
                    StringComparison.OrdinalIgnoreCase))
                {
                    txt.ReadOnly = true;
                    txt.BackColor =
                        Color.FromArgb(235, 235, 235);
                }

                cacONhap[cot.TenCot] = txt;
                pnlCot.Controls.Add(lbl);
                pnlCot.Controls.Add(txt);
                pnlNhapLieu.Controls.Add(pnlCot);
            }
        }

        private void TaiDuLieu()
        {
            try
            {
                dgvDuLieu.DataSource =
                    service.LayDanhSach(tenBang);

                giaTriKhoaDangChon = null;

                lblTrangThai.Text =
                    "Bảng: " + tenBang +
                    " | Số bản ghi: " + dgvDuLieu.Rows.Count;
            }
            catch (Exception ex)
            {
                HienThiLoi("Không tải được dữ liệu.", ex);
            }
        }

        private void TimKiemDuLieu()
        {
            try
            {
                dgvDuLieu.DataSource =
                    service.TimKiem(
                        tenBang, txtTimKiem.Text.Trim());

                giaTriKhoaDangChon = null;

                lblTrangThai.Text =
                    "Kết quả tìm kiếm: " +
                    dgvDuLieu.Rows.Count + " bản ghi.";
            }
            catch (Exception ex)
            {
                HienThiLoi("Tìm kiếm thất bại.", ex);
            }
        }

        private void ChonDongDuLieu()
        {
            if (dgvDuLieu.CurrentRow == null ||
                dgvDuLieu.CurrentRow.IsNewRow ||
                !dgvDuLieu.Columns.Contains(cotKhoaChinh))
            {
                giaTriKhoaDangChon = null;
                return;
            }

            object giaTri =
                dgvDuLieu.CurrentRow.Cells[cotKhoaChinh].Value;

            if (giaTri == null || giaTri == DBNull.Value)
            {
                giaTriKhoaDangChon = null;
                return;
            }

            giaTriKhoaDangChon = giaTri;

            foreach (var item in cacONhap)
            {
                if (dgvDuLieu.Columns.Contains(item.Key))
                {
                    object value =
                        dgvDuLieu.CurrentRow.Cells[item.Key].Value;

                    item.Value.Text =
                        value == null || value == DBNull.Value
                        ? ""
                        : Convert.ToString(
                            value, CultureInfo.CurrentCulture);
                }
            }
        }

        private Dictionary<string, object> LayDuLieuTuO(
            bool laThem)
        {
            Dictionary<string, object> duLieu =
                new Dictionary<string, object>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (var item in cacONhap)
            {
                CotThongTin cot = danhSachCot.First(
                    c => c.TenCot.Equals(
                        item.Key,
                        StringComparison.OrdinalIgnoreCase));

                if (!laThem &&
                    item.Key.Equals(
                        cotKhoaChinh,
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                string giaTri = item.Value.Text.Trim();

                if (giaTri.Length == 0)
                {
                    if (!cot.ChoPhepNull &&
                        !(laThem && cot.TuTang))
                    {
                        throw new ArgumentException(
                            "Vui lòng nhập dữ liệu cho cột: " +
                            cot.TenCot);
                    }

                    duLieu[item.Key] = DBNull.Value;
                    continue;
                }

                duLieu[item.Key] =
                    ChuyenKieuDuLieu(giaTri, cot);
            }

            return duLieu;
        }

        private object ChuyenKieuDuLieu(
            string giaTri, CotThongTin cot)
        {
            string kieu = cot.KieuDuLieu.ToLowerInvariant();

            try
            {
                switch (kieu)
                {
                    case "nvarchar":
                    case "varchar":
                    case "nchar":
                    case "char":
                    case "text":
                    case "ntext":
                        return giaTri;

                    case "int":
                        return int.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "bigint":
                        return long.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "smallint":
                        return short.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "tinyint":
                        return byte.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "decimal":
                    case "numeric":
                    case "money":
                    case "smallmoney":
                        return decimal.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "float":
                        return double.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "real":
                        return float.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "bit":
                        if (giaTri == "1" ||
                            giaTri.Equals(
                                "true",
                                StringComparison.OrdinalIgnoreCase) ||
                            giaTri.Equals(
                                "có",
                                StringComparison.OrdinalIgnoreCase))
                            return true;

                        if (giaTri == "0" ||
                            giaTri.Equals(
                                "false",
                                StringComparison.OrdinalIgnoreCase) ||
                            giaTri.Equals(
                                "không",
                                StringComparison.OrdinalIgnoreCase))
                            return false;

                        throw new FormatException(
                            "Nhập 1/0 hoặc true/false cho cột bit.");

                    case "date":
                    case "datetime":
                    case "datetime2":
                    case "smalldatetime":
                        return DateTime.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "datetimeoffset":
                        return DateTimeOffset.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "time":
                        return TimeSpan.Parse(
                            giaTri, CultureInfo.CurrentCulture);

                    case "uniqueidentifier":
                        return Guid.Parse(giaTri);

                    default:
                        return giaTri;
                }
            }
            catch (Exception ex)
            {
                throw new FormatException(
                    "Giá trị cột " + cot.TenCot +
                    " không đúng kiểu " + cot.KieuDuLieu +
                    ". Chi tiết: " + ex.Message);
            }
        }

        private void ThemDuLieu()
        {
            try
            {
                Dictionary<string, object> duLieu =
                    LayDuLieuTuO(true);

                service.Them(tenBang, duLieu);

                MessageBox.Show(
                    "Thêm dữ liệu thành công.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                TaiDuLieu();
                XoaTrangNhapLieu();
            }
            catch (Exception ex)
            {
                HienThiLoi("Không thể thêm dữ liệu.", ex);
            }
        }

        private void SuaDuLieu()
        {
            if (giaTriKhoaDangChon == null)
            {
                MessageBox.Show(
                    "Hãy chọn một dòng trong bảng trước khi sửa.",
                    "Chưa chọn dữ liệu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Dictionary<string, object> duLieu =
                    LayDuLieuTuO(false);

                service.CapNhat(
                    tenBang,
                    duLieu,
                    cotKhoaChinh,
                    giaTriKhoaDangChon);

                MessageBox.Show(
                    "Cập nhật dữ liệu thành công.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                TaiDuLieu();
                XoaTrangNhapLieu();
            }
            catch (Exception ex)
            {
                HienThiLoi("Không thể cập nhật dữ liệu.", ex);
            }
        }

        private void XoaDuLieu()
        {
            if (giaTriKhoaDangChon == null)
            {
                MessageBox.Show(
                    "Hãy chọn một dòng trong bảng trước khi xóa.",
                    "Chưa chọn dữ liệu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            DialogResult ketQua = MessageBox.Show(
                "Bà có chắc muốn xóa bản ghi đang chọn trong bảng " +
                tenBang + " không?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (ketQua != DialogResult.Yes)
                return;

            try
            {
                service.Xoa(
                    tenBang,
                    cotKhoaChinh,
                    giaTriKhoaDangChon);

                MessageBox.Show(
                    "Xóa dữ liệu thành công.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                TaiDuLieu();
                XoaTrangNhapLieu();
            }
            catch (Exception ex)
            {
                HienThiLoi(
                    "Không thể xóa dữ liệu. Bản ghi có thể đang " +
                    "được bảng khác tham chiếu.",
                    ex);
            }
        }

        private void XoaTrangNhapLieu()
        {
            giaTriKhoaDangChon = null;

            foreach (var item in cacONhap)
                item.Value.Clear();

            dgvDuLieu.ClearSelection();
            dgvDuLieu.CurrentCell = null;
        }

        private void HienThiLoi(
            string thongBao, Exception ex)
        {
            MessageBox.Show(
                thongBao + Environment.NewLine +
                Environment.NewLine + ex.Message,
                "Có lỗi xảy ra",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
