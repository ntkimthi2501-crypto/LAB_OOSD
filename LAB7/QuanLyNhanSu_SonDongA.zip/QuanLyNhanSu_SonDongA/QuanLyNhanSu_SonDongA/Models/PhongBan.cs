﻿
namespace QuanLyNhanSu_SonDongA.Models
{
    public class PhongBan
    {
        public int PhongBanID { get; set; }

        public string MaPhongBan { get; set; }

        public string TenPhongBan { get; set; }

        public string MoTa { get; set; }

        public bool DangHoatDong { get; set; }
    }
}
