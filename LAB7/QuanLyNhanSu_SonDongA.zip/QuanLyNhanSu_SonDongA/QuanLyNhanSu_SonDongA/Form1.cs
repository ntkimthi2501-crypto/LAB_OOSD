﻿
using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyNhanSu_SonDongA.Data;

namespace QuanLyNhanSu_SonDongA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.Load -= Form1_Load;
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string message;
            bool ketNoiThanhCong =
                DbConnection.TestConnection(out message);

            MessageBox.Show(
                message,
                "Kiểm tra kết nối SQL Server",
                MessageBoxButtons.OK,
                ketNoiThanhCong
                    ? MessageBoxIcon.Information
                    : MessageBoxIcon.Error
            );
        }
    }
}
