﻿
using System;
using System.Data.SqlClient;

namespace QuanLyNhanSu_SonDongA.Data
{
    public static class DbConnection
    {
        private static readonly string connectionString =
            @"Data Source=DESKTOP-CQGMJPS;Initial Catalog=QuanLyNhanSu_SonDongA;Integrated Security=True;TrustServerCertificate=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public static bool TestConnection(out string message)
        {
            try
            {
                using (SqlConnection conn = GetConnection())
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT DB_NAME()", conn))
                    {
                        string databaseName = cmd.ExecuteScalar().ToString();
                        message = "Kết nối database thành công!\n"
                                + "Database: " + databaseName;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                message = "Kết nối database thất bại!\n\nChi tiết lỗi:\n"
                        + ex.Message;

                return false;
            }
        }
    }
}
