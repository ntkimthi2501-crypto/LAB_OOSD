﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using QuanLyNhanSu_SonDongA.Data;

namespace QuanLyNhanSu_SonDongA.Forms
{
    public partial class FrmBangDuLieu : Form
    {
        private readonly string tenBang;
        private readonly string tenHienThi;

        private DataGridView dgvDuLieu;
        private Button btnTaiLai;
        private Label lblSoDong;

        public FrmBangDuLieu(string bang, string tieuDe)
        {
            InitializeComponent();

            tenBang = bang;
            tenHienThi = tieuDe;

            Text = "Dữ liệu - " + tenHienThi;
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1000, 600);
            MinimumSize = new Size(700, 400);

            TaoGiaoDien();
            TaiDuLieu();
        }

        private void TaoGiaoDien()
        {
            Controls.Clear();

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "DANH SÁCH " + tenHienThi.ToUpper();
            lblTieuDe.Dock = DockStyle.Top;
            lblTieuDe.Height = 60;
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            lblTieuDe.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            lblTieuDe.BackColor = Color.FromArgb(36, 92, 60);
            lblTieuDe.ForeColor = Color.White;

            Panel panelDuoi = new Panel();
            panelDuoi.Dock = DockStyle.Bottom;
            panelDuoi.Height = 55;

            btnTaiLai = new Button();
            btnTaiLai.Text = "Tải lại dữ liệu";
            btnTaiLai.Width = 140;
            btnTaiLai.Height = 32;
            btnTaiLai.Location = new Point(15, 10);
            btnTaiLai.Click += (sender, e) => TaiDuLieu();

            lblSoDong = new Label();
            lblSoDong.Text = "Số dòng: 0";
            lblSoDong.AutoSize = true;
            lblSoDong.Location = new Point(175, 18);

            panelDuoi.Controls.Add(btnTaiLai);
            panelDuoi.Controls.Add(lblSoDong);

            dgvDuLieu = new DataGridView();
            dgvDuLieu.Dock = DockStyle.Fill;
            dgvDuLieu.ReadOnly = true;
            dgvDuLieu.AllowUserToAddRows = false;
            dgvDuLieu.AllowUserToDeleteRows = false;
            dgvDuLieu.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dgvDuLieu.AutoSizeRowsMode =
                DataGridViewAutoSizeRowsMode.None;
            dgvDuLieu.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvDuLieu.MultiSelect = false;
            dgvDuLieu.RowHeadersVisible = false;
            dgvDuLieu.BackgroundColor = Color.White;
            dgvDuLieu.BorderStyle = BorderStyle.FixedSingle;

            Controls.Add(dgvDuLieu);
            Controls.Add(panelDuoi);
            Controls.Add(lblTieuDe);
        }

        private void TaiDuLieu()
        {
            try
            {
                using (SqlConnection conn = DbConnection.GetConnection())
                {
                    string sql = "SELECT * FROM dbo.[" + tenBang + "]";

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        dgvDuLieu.DataSource = dt;
                        lblSoDong.Text = "Số dòng: " + dt.Rows.Count;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải dữ liệu bảng " + tenBang +
                    ".\n\nChi tiết lỗi: " + ex.Message,
                    "Lỗi tải dữ liệu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
