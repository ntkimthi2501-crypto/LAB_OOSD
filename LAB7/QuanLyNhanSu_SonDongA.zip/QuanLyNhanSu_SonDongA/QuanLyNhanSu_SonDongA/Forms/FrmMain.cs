﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyNhanSu_SonDongA
{
    public partial class FrmMain : Form
    {
        private readonly string[,] danhSachBang =
        {
            { "Phòng ban", "PhongBan" },
            { "Nhân viên", "NhanVien" },
            { "Quyết định tuyển dụng", "QuyetDinhTuyenDung" },
            { "Hợp đồng lao động", "HopDongLaoDong" },
            { "Quyết định chức vụ", "QuyetDinhChucVu" },
            { "Quyết định lương", "QuyetDinhLuong" },
            { "Chấm công", "ChamCong" },
            { "Phiếu phụ trội", "PhieuPhuTroi" },
            { "Bảng lương", "BangLuong" },
            { "Quyết định khen thưởng", "QuyetDinhKhenThuong" },
            { "Phiếu chi khen thưởng", "PhieuChiKhenThuong" },
            { "Quyết định kỷ luật", "QuyetDinhKyLuat" },
            { "Phiếu thu phạt", "PhieuThuPhat" },
            { "Bảo hiểm", "BaoHiem" }
        };

        public FrmMain()
        {
            KhoiTaoGiaoDien();
        }

        private void KhoiTaoGiaoDien()
        {
            Text = "HỆ THỐNG QUẢN LÝ NHÂN SỰ - CÔNG TY SƠN ĐÔNG Á";
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(1000, 650);
            BackColor = Color.FromArgb(242, 245, 249);
            Font = new Font("Segoe UI", 10F);

            Panel pnlTieuDe = new Panel
            {
                Dock = DockStyle.Top,
                Height = 120,
                BackColor = Color.FromArgb(31, 78, 121)
            };

            Label lblTieuDe = new Label
            {
                Text = "QUẢN LÝ NHÂN SỰ",
                Dock = DockStyle.Top,
                Height = 65,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 23F, FontStyle.Bold)
            };

            Label lblPhuDe = new Label
            {
                Text = "CÔNG TY SƠN ĐÔNG Á",
                Dock = DockStyle.Top,
                Height = 35,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 13F, FontStyle.Regular)
            };

            pnlTieuDe.Controls.Add(lblPhuDe);
            pnlTieuDe.Controls.Add(lblTieuDe);

            Panel pnlNoiDung = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(30)
            };

            Label lblHuongDan = new Label
            {
                Text = "CHỌN DANH MỤC CẦN QUẢN LÝ",
                Dock = DockStyle.Top,
                Height = 60,
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Color.FromArgb(31, 78, 121),
                Font = new Font("Segoe UI", 15F, FontStyle.Bold)
            };

            FlowLayoutPanel pnlDanhMuc = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(5)
            };

            for (int i = 0; i < danhSachBang.GetLength(0); i++)
            {
                string tenHienThi = danhSachBang[i, 0];
                string tenBang = danhSachBang[i, 1];

                Button btn = new Button
                {
                    Text = tenHienThi,
                    Width = 245,
                    Height = 85,
                    Margin = new Padding(12),
                    BackColor = Color.White,
                    ForeColor = Color.FromArgb(31, 78, 121),
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                    Cursor = Cursors.Hand,
                    Tag = tenBang
                };

                btn.FlatAppearance.BorderColor =
                    Color.FromArgb(190, 205, 220);

                btn.FlatAppearance.BorderSize = 1;

                btn.Click += (s, e) =>
                {
                    string bang = Convert.ToString(
                        ((Button)s).Tag);

                    try
                    {
                        using (FrmCrud frm = new FrmCrud(bang))
                        {
                            frm.ShowDialog(this);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Không thể mở bảng " + bang +
                            "." + Environment.NewLine +
                            Environment.NewLine + ex.Message,
                            "Lỗi mở dữ liệu",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                };

                pnlDanhMuc.Controls.Add(btn);
            }

            lblHuongDan.Dock = DockStyle.Top;
            pnlNoiDung.Controls.Add(pnlDanhMuc);
            pnlNoiDung.Controls.Add(lblHuongDan);

            Label lblChanTrang = new Label
            {
                Text = "© 2026 - HỆ THỐNG QUẢN LÝ NHÂN SỰ SƠN ĐÔNG Á",
                Dock = DockStyle.Bottom,
                Height = 35,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Gray,
                BackColor = Color.White
            };

            Controls.Add(pnlNoiDung);
            Controls.Add(lblChanTrang);
            Controls.Add(pnlTieuDe);
        }
    }
}
