﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using QuanLyNhanSu_SonDongA.Data;

namespace QuanLyNhanSu_SonDongA.Services
{
    public class CrudService
    {
        // Danh sách bảng được phép truy cập
        private static readonly HashSet<string> BangHopLe =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "PhongBan",
            "NhanVien",
            "QuyetDinhTuyenDung",
            "HopDongLaoDong",
            "QuyetDinhChucVu",
            "QuyetDinhLuong",
            "ChamCong",
            "PhieuPhuTroi",
            "BangLuong",
            "QuyetDinhKhenThuong",
            "PhieuChiKhenThuong",
            "QuyetDinhKyLuat",
            "PhieuThuPhat",
            "BaoHiem"
        };

        private string KiemTraTenBang(string tenBang)
        {
            if (string.IsNullOrWhiteSpace(tenBang) ||
                !BangHopLe.Contains(tenBang))
            {
                throw new ArgumentException(
                    "Tên bảng không hợp lệ.");
            }

            return tenBang;
        }

        public DataTable LayDanhSach(string tenBang)
        {
            tenBang = KiemTraTenBang(tenBang);

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM dbo.[" + tenBang + "]", conn))
            {
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                return dt;
            }
        }

        public DataTable TimKiem(
            string tenBang,
            string tuKhoa)
        {
            tenBang = KiemTraTenBang(tenBang);

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = conn.CreateCommand())
            {
                // Tìm kiếm trên các cột dạng chữ.
                // Tên cột được lấy trực tiếp từ cấu trúc bảng.
                DataTable cauTruc = new DataTable();

                using (SqlDataAdapter adapter = new SqlDataAdapter(
                    "SELECT TOP 0 * FROM dbo.[" + tenBang + "]", conn))
                {
                    adapter.Fill(cauTruc);
                }

                List<string> dieuKien = new List<string>();

                foreach (DataColumn cot in cauTruc.Columns)
                {
                    if (cot.DataType == typeof(string))
                    {
                        dieuKien.Add("[" + cot.ColumnName + "] LIKE @kw");
                    }
                }

                if (dieuKien.Count == 0)
                    return LayDanhSach(tenBang);

                cmd.CommandText =
                    "SELECT * FROM dbo.[" + tenBang + "] WHERE " +
                    string.Join(" OR ", dieuKien);

                cmd.Parameters.Add("@kw", SqlDbType.NVarChar, 4000)
                    .Value = "%" + (tuKhoa ?? "") + "%";

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        public void Them(
            string tenBang,
            Dictionary<string, object> duLieu)
        {
            ThucHienGhi(tenBang, duLieu, false, null, null);
        }

        public void CapNhat(
            string tenBang,
            Dictionary<string, object> duLieu,
            string tenKhoa,
            object giaTriKhoa)
        {
            ThucHienGhi(
                tenBang, duLieu, true, tenKhoa, giaTriKhoa);
        }

        private void ThucHienGhi(
            string tenBang,
            Dictionary<string, object> duLieu,
            bool laCapNhat,
            string tenKhoa,
            object giaTriKhoa)
        {
            tenBang = KiemTraTenBang(tenBang);

            if (duLieu == null || duLieu.Count == 0)
                throw new ArgumentException(
                    "Chưa có dữ liệu để lưu.");

            using (SqlConnection conn = DbConnection.GetConnection())
            {
                conn.Open();

                HashSet<string> cotHopLe =
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);

                using (SqlCommand cmdCot = new SqlCommand(
                    "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS " +
                    "WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = @table",
                    conn))
                {
                    cmdCot.Parameters.AddWithValue("@table", tenBang);

                    using (SqlDataReader reader = cmdCot.ExecuteReader())
                    {
                        while (reader.Read())
                            cotHopLe.Add(reader.GetString(0));
                    }
                }

                if (laCapNhat &&
                    (string.IsNullOrWhiteSpace(tenKhoa) ||
                     !cotHopLe.Contains(tenKhoa)))
                {
                    throw new ArgumentException(
                        "Cột khóa không hợp lệ.");
                }

                foreach (string cot in duLieu.Keys)
                {
                    if (!cotHopLe.Contains(cot))
                        throw new ArgumentException(
                            "Cột không tồn tại: " + cot);
                }

                // Không cập nhật cột khóa chính.
                Dictionary<string, object> cacCot =
                    new Dictionary<string, object>(
                        StringComparer.OrdinalIgnoreCase);

                foreach (var item in duLieu)
                {
                    if (!laCapNhat ||
                        !item.Key.Equals(
                            tenKhoa,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        cacCot[item.Key] = item.Value;
                    }
                }

                if (cacCot.Count == 0)
                    throw new ArgumentException(
                        "Không có cột dữ liệu để lưu.");

                using (SqlCommand cmd = conn.CreateCommand())
                {
                    if (laCapNhat)
                    {
                        List<string> setClauses =
                            new List<string>();

                        int i = 0;
                        foreach (var item in cacCot)
                        {
                            string thamSo = "@p" + i++;
                            setClauses.Add(
                                "[" + item.Key + "] = " + thamSo);

                            cmd.Parameters.AddWithValue(
                                thamSo, item.Value ?? DBNull.Value);
                        }

                        cmd.CommandText =
                            "UPDATE dbo.[" + tenBang + "] SET " +
                            string.Join(", ", setClauses) +
                            " WHERE [" + tenKhoa + "] = @key";

                        cmd.Parameters.AddWithValue(
                            "@key", giaTriKhoa ?? DBNull.Value);
                    }
                    else
                    {
                        List<string> tenCot = new List<string>();
                        List<string> thamSo = new List<string>();

                        int i = 0;
                        foreach (var item in cacCot)
                        {
                            string p = "@p" + i++;
                            tenCot.Add("[" + item.Key + "]");
                            thamSo.Add(p);

                            cmd.Parameters.AddWithValue(
                                p, item.Value ?? DBNull.Value);
                        }

                        cmd.CommandText =
                            "INSERT INTO dbo.[" + tenBang + "] (" +
                            string.Join(", ", tenCot) + ") VALUES (" +
                            string.Join(", ", thamSo) + ")";
                    }

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Xoa(
            string tenBang,
            string tenKhoa,
            object giaTriKhoa)
        {
            tenBang = KiemTraTenBang(tenBang);

            if (string.IsNullOrWhiteSpace(tenKhoa) ||
                !Regex.IsMatch(tenKhoa, @"^[A-Za-z_][A-Za-z0-9_]*$"))
            {
                throw new ArgumentException(
                    "Tên cột khóa không hợp lệ.");
            }

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText =
                    "DELETE FROM dbo.[" + tenBang +
                    "] WHERE [" + tenKhoa + "] = @key";

                cmd.Parameters.AddWithValue(
                    "@key", giaTriKhoa ?? DBNull.Value);

                conn.Open();

                int soDong = cmd.ExecuteNonQuery();

                if (soDong == 0)
                    throw new Exception(
                        "Không tìm thấy dữ liệu cần xóa.");
            }
        }
    }
}
